<?php
session_start();
include('Koneksi/db_connection.php');

// Cek apakah pengguna sudah login
if (!isset($_SESSION['user_id'])) {
    header("Location: login.html");
    exit();
}

// Ambil data pengguna dari sesi
$user_id = $_SESSION['user_id'];

// Ambil data pengguna dari database
$query = "SELECT * FROM users WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $username = $_POST['username']; // Ambil data username
    $name = $_POST['name'];
    $dob = $_POST['dob'];
    $phone = $_POST['phone'];
    $bio = $_POST['bio'];
    $document_password = $_POST['document_password'];
    $address = $_POST['address']; // Ambil data alamat

    // Cek apakah ada file foto yang diunggah
    if (isset($_FILES['photo']) && $_FILES['photo']['error'] == UPLOAD_ERR_OK) {
        $photo = $_FILES['photo'];
        $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];

        if (in_array($photo['type'], $allowed_types)) {
            $upload_dir = 'uploads/';
            $photo_name = basename($photo['name']);
            $upload_file = $upload_dir . $photo_name;

            if (move_uploaded_file($photo['tmp_name'], $upload_file)) {
                // Update foto pengguna di database
                $query = "UPDATE users SET photo = ? WHERE id = ?";
                $stmt = $conn->prepare($query);
                $stmt->bind_param("si", $photo_name, $user_id);
                if (!$stmt->execute()) {
                    $error = "Error updating photo.";
                }
            } else {
                $error = "Failed to upload photo.";
            }
        } else {
            $error = "Invalid file type.";
        }
    }

    // Update data users termasuk alamat, email, dan username
    $query = "UPDATE users SET username = ?, email = ?, name = ?, dob = ?, phone = ?, bio = ?, document_password = ?, address = ? WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ssssssssi", $username, $email, $name, $dob, $phone, $bio, $document_password, $address, $user_id);

    if ($stmt->execute()) {
        header("Location: users.php");
        exit();
    } else {
        $error = "Error updating users.";
    }
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Edit Users - Website Arsip Documents</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet" />
    <!-- Custom Styles -->
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
        }

        .container {
            max-width: 800px;
            padding: 2rem;
            margin: 0 auto;
        }

        .jumbotron {
            background-color: #ffffff;
            padding: 2rem;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .jumbotron h2.display-4 {
            font-size: 1.5rem;
            color: #00796b;
        }

        .form-group label {
            font-weight: bold;
            color: #00796b;
        }

        .btn-primary {
            background-color: #00796b;
            border-color: #00796b;
        }

        .btn-primary:hover {
            background-color: #004d40;
            border-color: #004d40;
        }

        .btn-secondary {
            background-color: #e0f2f1;
            border-color: #b2dfdb;
            color: #00796b;
        }

        .btn-secondary:hover {
            background-color: #b2dfdb;
            border-color: #80cbc4;
            color: #004d40;
        }

        .alert-danger {
            background-color: #f8d7da;
            color: #721c24;
            border-color: #f5c6cb;
        }

        .btn-wrapper {
            margin-top: 1rem;
        }

        .form-group img {
            max-width: 100px;
            height: auto;
            border-radius: .25rem;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="jumbotron">
            <h2 class="display-4">Edit Profile</h2>
            <?php if (isset($error)): ?>
                <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>
            <form action="edit_users.php" method="post" enctype="multipart/form-data">
                <input type="hidden" name="id" value="<?php echo htmlspecialchars($user['id']); ?>">
                <div class="form-group">
                    <label for="username">Username:</label>
                    <input type="text" class="form-control" id="username" name="username" value="<?php echo htmlspecialchars($user['username']); ?>" required>
                </div>
                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
                </div>
                <div class="form-group">
                    <label for="name">Nama:</label>
                    <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($user['name']); ?>" required>
                </div>
                <div class="form-group">
                    <label for="dob">Tanggal Lahir:</label>
                    <input type="date" class="form-control" id="dob" name="dob" value="<?php echo htmlspecialchars($user['dob']); ?>">
                </div>
                <div class="form-group">
                    <label for="phone">Nomor WhatsApp:</label>
                    <input type="text" class="form-control" id="phone" name="phone" value="<?php echo htmlspecialchars($user['phone']); ?>">
                </div>
                <div class="form-group">
                    <label for="bio">Data Diri:</label>
                    <textarea class="form-control" id="bio" name="bio" rows="3"><?php echo htmlspecialchars($user['bio']); ?></textarea>
                </div>
                <div class="form-group">
                    <label for="address">Alamat:</label>
                    <input type="text" class="form-control" id="address" name="address" value="<?php echo htmlspecialchars($user['address']); ?>">
                </div>
                <div class="form-group">
                    <label for="photo">Unggah Foto:</label>
                    <input type="file" class="form-control-file" id="photo" name="photo" accept="image/*">
                    <?php if (!empty($user['photo'])): ?>
                        <p class="mt-2">Foto saat ini:</p>
                        <img src="uploads/<?php echo htmlspecialchars($user['photo']); ?>" alt="Current Photo">
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <label for="document_password">Password Dokumen:</label>
                    <input type="text" class="form-control" id="document_password" name="document_password" value="<?php echo htmlspecialchars($user['document_password']); ?>">
                </div>
                <div class="btn-wrapper">
                    <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                    <a href="users.php" class="btn btn-secondary">Batal</a>
                </div>
            </form>
        </div>
    </div>

    <!-- Optional JavaScript -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>