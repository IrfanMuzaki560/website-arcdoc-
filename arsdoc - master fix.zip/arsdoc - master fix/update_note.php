<?php
session_start();
include('Koneksi/db_connection.php');

// Buat koneksi
$conn = new mysqli($servername, $username, $password, $database);
// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Ambil data dari formulir dengan pengecekan
$file_name = isset($_POST['file_name']) ? $_POST['file_name'] : '';
$error_description = isset($_POST['error_description']) ? $_POST['error_description'] : '';
$feature_description = isset($_POST['feature_description']) ? $_POST['feature_description'] : '';
$aditional_info = isset($_POST['aditional_info']) ? $_POST['aditional_info'] : ''; // Pastikan aditional_info ada

// Query untuk menyimpan data catatan
$sql = "INSERT INTO project_notes (file_name, error_description, feature_description, aditional_info) VALUES (?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssss", $file_name, $error_description, $feature_description, $aditional_info);

if ($stmt->execute()) {
    // Jika berhasil, arahkan ke project.php
    header("Location: project.php");
    exit(); // Pastikan untuk berhenti eksekusi skrip setelah pengalihan
} else {
    echo "Terjadi kesalahan: " . $stmt->error;
}

$stmt->close();
$conn->close();
