<?php
session_start();
include('Koneksi/db_connection.php');

// Aktifkan error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Cek apakah pengguna sudah login dan memiliki hak akses admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.html");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = $_POST['user_id'];
    $role = $_POST['role'];

    // Validasi input
    if (!in_array($role, ['admin', 'user'])) {
        echo "Hak akses tidak valid.";
        exit();
    }

    // Update hak akses di database
    $sql = "UPDATE users SET role = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("si", $role, $user_id);

    if ($stmt->execute()) {
        echo "Hak akses berhasil diperbarui.";
    } else {
        echo "Terjadi kesalahan saat memperbarui hak akses.";
    }

    $stmt->close();
}

$conn->close();
