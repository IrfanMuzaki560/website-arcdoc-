<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Edit Catatan</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" />
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
        }

        .container {
            max-width: 800px;
            padding: 2rem;
            margin: 0 auto;
        }

        .jumbotron {
            background-color: #ffffff;
            padding: 2rem;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .jumbotron h2.display-4 {
            font-size: 1.5rem;
            color: #00796b;
        }

        .form-group label {
            font-weight: bold;
            color: #00796b;
        }

        .btn-primary {
            background-color: #00796b;
            border-color: #00796b;
        }

        .btn-primary:hover {
            background-color: #004d40;
            border-color: #004d40;
        }

        .btn-secondary {
            background-color: #e0f2f1;
            /* Warna latar belakang tombol Kembali */
            border-color: #b2dfdb;
            /* Warna border tombol Kembali */
            color: #00796b;
            /* Warna font tombol Kembali */
        }

        .btn-secondary:hover {
            background-color: #b2dfdb;
            /* Warna latar belakang tombol Kembali saat hover */
            border-color: #80cbc4;
            /* Warna border tombol Kembali saat hover */
            color: #004d40;
            /* Warna font tombol Kembali saat hover */
        }

        .alert-danger {
            background-color: #f8d7da;
            color: #721c24;
            border-color: #f5c6cb;
        }

        .btn-wrapper {
            margin-top: 1rem;
        }
    </style>
</head>

<body>
    <div class="container">

        <!-- Form Edit Catatan -->
        <?php
        session_start();
        include('Koneksi/db_connection.php');

        // Buat koneksi
        $conn = new mysqli($servername, $username, $password, $database);

        // Cek koneksi
        if ($conn->connect_error) {
            die("Koneksi gagal: " . $conn->connect_error);
        }

        // Ambil ID dari URL
        $id = intval($_GET['id']);

        // Query untuk mengambil data catatan
        $sql = "SELECT * FROM project_notes WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
        } else {
            echo "<div class='alert alert-danger'>Catatan tidak ditemukan.</div>";
            exit;
        }

        $stmt->close();
        $conn->close();
        ?>

        <div class="jumbotron">
            <h2 class="display-4">Edit Catatan</h2>
            <form action="update_note.php" method="post">
                <input type="hidden" name="id" value="<?php echo htmlspecialchars($row['id']); ?>">
                <div class="form-group">
                    <label for="file_name">Nama File</label>
                    <input type="text" class="form-control" id="file_name" name="file_name" value="<?php echo htmlspecialchars($row['file_name']); ?>" required>
                </div>
                <div class="form-group">
                    <label for="error_description">Keterangan Error</label>
                    <textarea class="form-control" id="error_description" name="error_description" rows="3" required><?php echo htmlspecialchars($row['error_description']); ?></textarea>
                </div>
                <div class="form-group">
                    <label for="feature_description">Keterangan Tambahan Fitur</label>
                    <textarea class="form-control" id="feature_description" name="feature_description" rows="3"><?php echo htmlspecialchars($row['feature_description']); ?></textarea>
                </div>
                <div class="btn-wrapper">
                    <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                    <a href="project.php" class="btn btn-secondary">Batal</a> <!-- Tombol Kembali -->
                </div>
            </form>
        </div>
    </div>

    <!-- JavaScript -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>