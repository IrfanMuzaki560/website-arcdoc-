<?php
include('Koneksi/db_connection.php'); // Pastikan file koneksi ada

session_start(); // Mulai sesi
if (!isset($_SESSION['user_id'])) {
    die("Harap login terlebih dahulu."); // Cek apakah user_id tersedia di sesi
}

$user_id = $_SESSION['user_id']; // Ambil user_id dari sesi
$sql = "SELECT * FROM tdl WHERE user_id = ? ORDER BY tanggal DESC"; // Query dengan filter user_id
$stmt = $conn->prepare($sql);

if ($stmt === false) {
    die("Query error: " . $conn->error);
}

$stmt->bind_param("i", $user_id); // Bind user_id ke query
$stmt->execute();
$result = $stmt->get_result();

if (!$result) {
    die("Query error: " . $conn->error); // Menangani error query
}

// Pagination
$rowsPerPage = 10; // Jumlah data per halaman
$currentPage = isset($_GET['page']) ? (int)$_GET['page'] : 1; // Halaman saat ini
if ($currentPage < 1) $currentPage = 1; // Halaman tidak valid, reset ke 1
$offset = ($currentPage - 1) * $rowsPerPage; // Hitung offset

// Query data
$sql = "SELECT * FROM tdl WHERE user_id = ? ORDER BY tanggal DESC LIMIT ? OFFSET ?";
$stmt = $conn->prepare($sql);

if ($stmt === false) {
    die("Query error: " . $conn->error);
}

$stmt->bind_param("iii", $user_id, $rowsPerPage, $offset); // Bind user_id, limit, dan offset
$stmt->execute();
$result = $stmt->get_result();

// Total data
$totalSql = "SELECT COUNT(*) as total FROM tdl WHERE user_id = ?";
$totalStmt = $conn->prepare($totalSql);
$totalStmt->bind_param("i", $user_id);
$totalStmt->execute();
$totalResult = $totalStmt->get_result();
$totalRow = $totalResult->fetch_assoc();
$totalRows = $totalRow['total']; // Total baris data
$totalPages = ceil($totalRows / $rowsPerPage); // Total halaman

?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>To-Do List</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script>
        function tambahKegiatan() {
            var div = document.createElement('div');
            div.classList.add('form-group', 'col-md-4');
            div.innerHTML = '<label>Kegiatan</label><input type="text" class="form-control" name="kegiatan[]" required>';
            document.getElementById('kegiatanDiv').appendChild(div);
        }

        function filterTable() {
            var input, filter, table, tr, td, i, txtValue, criteria;
            input = document.getElementById("searchInput");
            filter = input.value.toUpperCase();
            table = document.getElementById("dataTable");
            tr = table.getElementsByTagName("tr");
            criteria = document.getElementById("searchCriteria").value;

            for (i = 1; i < tr.length; i++) {
                td = tr[i].getElementsByTagName("td");
                if (td) {
                    var match = false;
                    // Periksa sesuai dengan kriteria pencarian yang dipilih
                    if (criteria == "nama" && td[0]) {
                        txtValue = td[0].textContent || td[0].innerText;
                        match = txtValue.toUpperCase().indexOf(filter) > -1;
                    } else if (criteria == "hari" && td[1]) { // Pastikan kolom "Hari" adalah td[1]
                        txtValue = td[1].textContent || td[1].innerText; // Ubah td[3] menjadi td[1]
                        match = txtValue.toUpperCase().indexOf(filter) > -1;
                    } else if (criteria == "kegiatan" && td[3]) {
                        txtValue = td[3].textContent || td[3].innerText;
                        match = txtValue.toUpperCase().indexOf(filter) > -1;
                    } else if (criteria == "tanggal" && td[2]) {
                        txtValue = td[2].textContent || td[2].innerText;
                        match = txtValue.toUpperCase().indexOf(filter) > -1;
                    }
                    if (criteria == "proses" && td[6]) {
                        txtValue = td[6].textContent || td[6].innerText;
                        match = txtValue.toUpperCase().indexOf(filter) > -1;
                    }


                    // Menyembunyikan atau menampilkan baris sesuai dengan kecocokan
                    if (match) {
                        tr[i].style.display = "";
                    } else {
                        tr[i].style.display = "none";
                    }
                }
            }
        }


        function downloadCSV() {
            var csv = [];
            var rows = document.querySelectorAll("#dataTable tr");

            for (var i = 0; i < rows.length; i++) {
                var row = [],
                    cols = rows[i].querySelectorAll("td, th");
                for (var j = 0; j < cols.length - 1; j++) {
                    row.push(cols[j].innerText);
                }
                csv.push(row.join(","));
            }

            var csvFile = new Blob([csv.join("\n")], {
                type: "text/csv"
            });
            var downloadLink = document.createElement("a");
            downloadLink.download = "ToDoList.csv";
            downloadLink.href = window.URL.createObjectURL(csvFile);
            downloadLink.style.display = "none";
            document.body.appendChild(downloadLink);
            downloadLink.click();
        }
    </script>
    <style>
        /* Style customization */
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            height: 100vh;
            display: flex;
            flex-direction: column;
        }

        .container {
            flex: 1;
            margin-top: 80px;
            padding-bottom: 20px;
        }

        .card {
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .card-header {
            background-color: rgba(1, 13, 24, 0.81);
            color: #ffffff;
            font-weight: bold;
        }

        .form-group label {
            font-weight: bold;
        }

        .table {
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .table thead th {
            background-color: rgba(1, 13, 24, 0.81);
            color: white;
            font-size: 14px;
        }

        .table tbody tr:nth-child(even) {
            background-color: #f1f1f1;
        }

        .table tbody tr:hover {
            background-color: #b2dfdb;
        }

        .input-group-text {
            background-color: rgba(1, 13, 24, 0.81);
            color: white;
        }

        .btn-success {
            background-color: rgb(78, 82, 81);
            border-color: rgb(78, 82, 81);
        }

        .btn-success:hover {
            background-color: rgb(78, 82, 81);
            border-color: rgb(78, 82, 81);
        }


        @media (max-width: 768px) {
            .form-inline {
                flex-direction: column;
                align-items: stretch;
            }

            .navbar-collapse {
                flex-direction: column;
            }

            .table {
                font-size: 12px;
            }
        }
    </style>
</head>

<!--Required untuk kolom wajib di isi-->
<div class="container">
    <div class="card mb-4">
        <div class="card-header">Tambah TDL</div>
        <div class="card-body">
            <form id="barangForm" method="post" action="simpan_tdl.php">
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label>Nama</label>
                        <input type="text" class="form-control" name="nama">
                    </div>
                    <div class="form-group col-md-3">
                        <label>Hari</label>
                        <input type="text" class="form-control" name="hari" required>
                    </div>
                    <div class="form-group col-md-3">
                        <label>Tanggal</label>
                        <input type="date" class="form-control" name="tanggal" required>
                    </div>
                </div>

                <div id="kegiatanDiv" class="form-row">
                    <div class="form-group col-md-4">
                        <label>Kegiatan</label>
                        <input type="text" class="form-control" name="kegiatan[]" required>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group col-md-3">
                        <label>Mulai (Jam)</label>
                        <input type="time" class="form-control" name="start_jam">
                    </div>
                    <div class="form-group col-md-3">
                        <label>Selesai (Jam)</label>
                        <input type="time" class="form-control" name="selesai_jam">
                    </div>
                    <div class="form-group col-md-3">
                        <label>Proses</label>
                        <select class="form-control" name="proses">
                            <option value="Selesai">Selesai</option>
                            <option value="Belum">Belum</option>

                        </select>
                    </div>
                </div>
                <button type="submit" class="btn btn-success"><i class="fas fa-save"></i> Simpan</button>
                <a href="index.php" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Kembali
                </a>
            </form>
        </div>
    </div>

    <div class="mb-4">
        <div class="form-inline">
            <div class="input-group mr-2">
                <div class="input-group-prepend">
                    <span class="input-group-text"><i class="fas fa-search"></i></span>
                </div>
                <input type="text" id="searchInput" class="form-control" placeholder="Cari..." onkeyup="filterTable()">
            </div>
            <div class="input-group">
                <select id="searchCriteria" class="form-control" onchange="filterTable()">
                    <option value="nama">Nama</option>
                    <option value="hari">Hari</option>
                    <option value="tanggal">Tanggal</option>
                    <option value="kegiatan">Kegiatan</option>
                    <option value="proses">Proses</option>

                </select>
            </div>
        </div>
        <button class="btn btn-success mt-3" onclick="downloadCSV()"><i class="fas fa-file-download"></i> Download CSV</button>
    </div>

    <table class="table mt-3" id="dataTable">
        <thead>
            <tr>
                <th>Nama</th>
                <th>Hari</th> <!-- Kolom Hari -->
                <th>Tanggal</th>
                <th>Kegiatan</th>
                <th>Mulai</th>
                <th>Selesai</th>
                <th>Proses</th>
                <th>Total Waktu</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()): ?>
                <?php
                // Waktu mulai dan selesai dari database
                $start_time = $row['start_jam'];
                $end_time = $row['selesai_jam'];

                // Konversi waktu ke menit total
                $start_minutes = (int)date('H', strtotime($start_time)) * 60 + (int)date('i', strtotime($start_time));
                $end_minutes = (int)date('H', strtotime($end_time)) * 60 + (int)date('i', strtotime($end_time));

                // Total menit dalam sehari
                $minutes_in_a_day = 24 * 60;

                // Jika waktu selesai lebih kecil dari waktu mulai, tambahkan satu hari (1440 menit)
                if ($end_minutes < $start_minutes) {
                    $end_minutes += $minutes_in_a_day;
                }

                // Hitung durasi dalam menit dan konversi ke jam dan menit
                $duration_minutes = $end_minutes - $start_minutes;
                $hours = floor($duration_minutes / 60);
                $minutes = $duration_minutes % 60;
                ?>

                <tr>
                    <td><?= htmlspecialchars($row['nama']) ?></td>
                    <td><?= htmlspecialchars($row['hari']) ?></td> <!-- Kolom Hari -->
                    <td><?= htmlspecialchars($row['tanggal']) ?></td>
                    <td><?= htmlspecialchars($row['kegiatan']) ?></td>
                    <td><?= htmlspecialchars($row['start_jam']) ?></td>
                    <td><?= htmlspecialchars($row['selesai_jam']) ?></td>
                    <td><?= htmlspecialchars($row['proses']) ?></td>
                    <td>
                        <?php if (strtolower($row['proses']) === 'selesai'): ?> <!-- Cek jika statusnya selesai -->
                            <?= $hours ?> jam <?= $minutes ?> menit
                        <?php else: ?>
                            -
                        <?php endif; ?>
                    </td>
                    <td>
                        <a href="edit_tdl.php?id=<?= $row['id'] ?>" class="btn btn-warning btn-sm">
                            <i class="fas fa-edit"></i> Edit
                        </a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <div id="pagination" class="mt-3">
        <nav>
            <ul class="pagination">
                <!-- Tombol Previous -->
                <?php if ($currentPage > 1): ?>
                    <li class="page-item">
                        <a class="page-link" href="?page=<?= $currentPage - 1 ?>">Previous</a>
                    </li>
                <?php else: ?>
                    <li class="page-item disabled">
                        <a class="page-link" href="#">Previous</a>
                    </li>
                <?php endif; ?>

                <!-- Nomor Halaman -->
                <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                    <li class="page-item <?= $i == $currentPage ? 'active' : '' ?>">
                        <a class="page-link" href="?page=<?= $i ?>"><?= $i ?></a>
                    </li>
                <?php endfor; ?>

                <!-- Tombol Next -->
                <?php if ($currentPage < $totalPages): ?>
                    <li class="page-item">
                        <a class="page-link" href="?page=<?= $currentPage + 1 ?>">Next</a>
                    </li>
                <?php else: ?>
                    <li class="page-item disabled">
                        <a class="page-link" href="#">Next</a>
                    </li>
                <?php endif; ?>
            </ul>
        </nav>
    </div>

</div>

</div>
<script>
    document.addEventListener("DOMContentLoaded", function() {
        const rowsPerPage = 10;
        let currentPage = 1;
        const table = document.getElementById("dataTable");
        const tbody = table.querySelector("tbody");
        const pagination = document.getElementById("pagination");
        let rows = Array.from(tbody.rows);

        function displayTablePage(page) {
            tbody.innerHTML = ""; // Clear the table body
            const start = (page - 1) * rowsPerPage;
            const end = start + rowsPerPage;
            const paginatedRows = rows.slice(start, end);
            paginatedRows.forEach(row => tbody.appendChild(row)); // Append rows for the current page

            updatePaginationControls(page);
        }
    });
</script>

</body>

</html>