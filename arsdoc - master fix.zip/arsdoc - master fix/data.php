<?php
session_start();
include('Koneksi/db_connection.php');

// Pastikan user sudah login
if (!isset($_SESSION['user_id'])) {
    echo "<script>alert('Harap login terlebih dahulu.'); window.location.href = 'login.php';</script>";
    exit;
}

$user_id = $_SESSION['user_id']; // ID user yang sedang login

// Buat koneksi
$conn = new mysqli($servername, $username, $password, $database);
// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Proses form jika disubmit
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ambil data dari form
    $nama_barang = isset($_POST['nama_barang']) ? $_POST['nama_barang'] : '';
    $jumlah_barang = isset($_POST['jumlah_barang']) ? $_POST['jumlah_barang'] : '';
    $harga_beli = isset($_POST['harga_beli']) ? $_POST['harga_beli'] : '';
    $tempat_beli = isset($_POST['tempat_beli']) ? $_POST['tempat_beli'] : '';
    $tanggal_beli = isset($_POST['tanggal_beli']) ? $_POST['tanggal_beli'] : '';
    $jumlah_sekarang = isset($_POST['jumlah_sekarang']) ? $_POST['jumlah_sekarang'] : '';

    // Proses upload gambar
    $gambar_nota = '';
    if (!empty($_FILES['gambar_nota']['name'])) {
        $target_dir = "uploads/";
        $gambar_nota = basename($_FILES['gambar_nota']['name']);
        $target_file = $target_dir . $gambar_nota;

        // Validasi tipe file
        $allowed_types = ['jpg', 'jpeg', 'png', 'gif'];
        $file_type = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
        if (!in_array($file_type, $allowed_types)) {
            echo "<script>alert('Hanya file JPG, JPEG, PNG, dan GIF yang diperbolehkan.');</script>";
            $gambar_nota = ''; // Kosongkan jika file tidak valid
        } else {
            // Pindahkan file ke folder tujuan
            if (!move_uploaded_file($_FILES['gambar_nota']['tmp_name'], $target_file)) {
                echo "<script>alert('Gagal mengunggah gambar.');</script>";
                $gambar_nota = ''; // Kosongkan jika gagal upload
            }
        }
    }

    // Validasi input
    if (empty($nama_barang) || empty($jumlah_barang) || empty($harga_beli) || empty($tempat_beli) || empty($tanggal_beli) || empty($jumlah_sekarang)) {
        echo "<script>alert('Semua field harus diisi.');</script>";
    } else {
        // Query untuk menyimpan data barang dengan user_id
        $sql = "INSERT INTO barang (nama_barang, jumlah_barang, harga_beli, tempat_beli, tanggal_beli, jumlah_sekarang, gambar_nota, user_id) 
                VALUES ('$nama_barang', '$jumlah_barang', '$harga_beli', '$tempat_beli', '$tanggal_beli', '$jumlah_sekarang', '$gambar_nota', $user_id)";

        if ($conn->query($sql) === TRUE) {
            echo "<script>alert('Data berhasil disimpan');</script>";
        } else {
            echo "<script>alert('Error: " . $sql . "<br>" . $conn->error . "');</script>";
        }
    }
}

// Query untuk mengambil data barang berdasarkan user yang login
$sql = "SELECT * FROM barang WHERE user_id = $user_id";
$result = $conn->query($sql);

// Tutup koneksi
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Catatan Inventaris</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" />
    <link rel="stylesheet" href="styles.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">

    <style>
        /* Style customization */
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            height: 100vh;
            display: flex;
            flex-direction: column;
        }

        .container {
            flex: 1;
            margin-top: 80px;
            padding-bottom: 20px;
        }

        .card {
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .card-header {
            background-color: rgba(1, 13, 24, 0.81);
            color: #ffffff;
            font-weight: bold;
        }

        .form-group label {
            font-weight: bold;
        }

        .table {
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .table thead th {
            background-color: rgba(1, 13, 24, 0.81);
            color: white;
            font-size: 14px;
        }

        .table tbody tr:nth-child(even) {
            background-color: #f1f1f1;
        }

        .table tbody tr:hover {
            background-color: #b2dfdb;
        }

        .input-group-text {
            background-color: rgba(1, 13, 24, 0.81);
            color: white;
        }

        .btn-success {
            background-color: #80cbc4;
            border-color: #80cbc4;
        }

        .btn-success:hover {
            background-color: #004d40;
            border-color: #004d40;
        }

        @media (max-width: 768px) {
            .form-inline {
                flex-direction: column;
                align-items: stretch;
            }

            .navbar-collapse {
                flex-direction: column;
            }

            .table {
                font-size: 12px;
            }
        }
    </style>
</head>

<body>

    <!-- Content Area -->
    <div class="container mt-5 pt-4">

        <!-- Form Input Barang -->
        <div class="card mb-4">
            <div class="card-header">Tambah Barang</div>
            <div class="card-body">
                <form id="barangForm" method="post">
                    <div class="form-group">
                        <label for="namaBarang">Nama Barang</label>
                        <input type="text" class="form-control" id="namaBarang" name="nama_barang" required>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-3">
                            <label for="jumlah">Jumlah Barang</label>
                            <input type="number" class="form-control" id="jumlah" name="jumlah_barang" required>
                        </div>
                        <div class="form-group col-md-3">
                            <label for="hargaBeli">Harga Beli</label>
                            <input type="number" class="form-control" id="hargaBeli" name="harga_beli" required>
                        </div>
                        <div class="form-group col-md-3">
                            <label for="tempatBeli">Tempat Beli</label>
                            <input type="text" class="form-control" id="tempatBeli" name="tempat_beli" required>
                        </div>
                        <div class="form-group col-md-3">
                            <label for="tanggalBeli">Tanggal Beli</label>
                            <input type="date" class="form-control" id="tanggalBeli" name="tanggal_beli" required>
                        </div>
                        <div class="form-group col-md-3">
                            <label for="jumlahSekarang">Total Harga</label>
                            <input type="number" class="form-control" id="jumlahSekarang" name="jumlah_sekarang" required>
                        </div>
                        <div class="form-group">
                            <label for="gambarNota">Upload Bukti Nota</label>
                            <input type="file" class="form-control" id="gambarNota" name="gambar_nota" accept="image/*">
                        </div>


                    </div>
                    <!-- Tombol Simpan Data -->
                    <button type="submit" class="btn btn-success">
                        <i class="fas fa-save"></i> Simpan Data
                    </button>

                    <!-- Tombol Kembali -->
                    <a href="index.php" class="btn btn-secondary">
                        <i class="fas fa-arrow-left"></i> Kembali
                    </a>

                </form>
            </div>
        </div>

        <!-- Search and Download Controls -->
        <div class="mb-3">
            <div class="form-inline">
                <!-- Input Search -->
                <div class="input-group mr-2">
                    <div class="input-group-prepend">
                        <span class="input-group-text"><i class="fas fa-search"></i></span>
                    </div>
                    <input type="text" id="searchInput" class="form-control" placeholder="Cari barang..." onkeyup="filterTable()">
                </div>

                <!-- Dropdown untuk memilih kategori pencarian -->
                <div class="input-group">
                    <select id="searchCriteria" class="form-control" onchange="filterTable()">
                        <option value="nama_barang">Nama Barang</option>
                        <option value="tempat_beli">Tempat Beli</option>
                        <option value="tanggal">Tanggal</option>
                    </select>
                </div>
            </div>

            <!-- Tombol Download CSV -->
            <button id="downloadBtn" class="btn btn-success mt-2" onclick="downloadCSV()">
                <i class="fas fa-file-download"></i> Download CSV
            </button>
        </div>

        <!-- Tabel Barang -->
        <div class="table-responsive">
            <table class="table table-striped" id="barangTable">
                <thead>
                    <tr>
                        <th>Nama Barang</th>
                        <th>Jumlah Barang</th>
                        <th>Harga Beli</th>
                        <th>Tempat Beli</th>
                        <th>Tanggal Beli</th>
                        <th>Total Harga</th>
                        <th>Bukti Nota</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr>
                        <td>{$row['nama_barang']}</td>
                        <td>{$row['jumlah_barang']}</td>
                        <td>{$row['harga_beli']}</td>
                        <td>{$row['tempat_beli']}</td>
                        <td>{$row['tanggal_beli']}</td>
                        <td>{$row['jumlah_sekarang']}</td>
                        <td>";
                            if (!empty($row['gambar_nota'])) {
                                // Tampilkan nama file gambar nota sebagai link
                                echo "<a href='#' onclick='showImageModal(\"uploads/{$row['gambar_nota']}\")'>{$row['gambar_nota']}</a>";
                            } else {
                                echo "Tidak ada gambar";
                            }
                            echo "</td>
                        <td>
                            <a href='edit_barang.php?id={$row['id']}' class='btn btn-warning btn-sm'>
                                <i class='fas fa-edit'></i> Edit
                            </a>
                            <a href='delete_barang.php?id={$row['id']}' class='btn btn-danger btn-sm'>
                                <i class='fas fa-trash-alt'></i> Hapus
                            </a>
                        </td>
                    </tr>";
                        }
                    } else {
                        echo "<tr><td colspan='8' class='text-center'>Tidak ada data</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
        </table>
    </div>
    </div>
    <!-- Modal untuk Menampilkan Gambar Detail -->
    <div class="modal fade" id="imageModal" tabindex="-1" aria-labelledby="imageModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="imageModalLabel">Gambar Nota</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body text-center">
                    <img id="modalImage" src="" alt="Gambar Nota" style="max-width: 100%; height: auto;">
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <!-- JavaScript -->
    <script>
        // Fungsi untuk menampilkan gambar di modal
        function showImageModal(imageUrl) {
            // Set URL gambar ke elemen gambar dalam modal
            document.getElementById('modalImage').src = imageUrl;
            // Tampilkan modal menggunakan Bootstrap
            new bootstrap.Modal(document.getElementById('imageModal')).show();
        }
        document.addEventListener("DOMContentLoaded", function() {
            // Ambil elemen input jumlah_barang, harga_beli, dan jumlah_sekarang
            let jumlahBarangInput = document.getElementById("jumlah");
            let hargaBeliInput = document.getElementById("hargaBeli");
            let jumlahSekarangInput = document.getElementById("jumlahSekarang");

            // Fungsi untuk menghitung jumlah_sekarang
            function updateJumlahSekarang() {
                let jumlahBarang = parseFloat(jumlahBarangInput.value) || 0;
                let hargaBeli = parseFloat(hargaBeliInput.value) || 0;
                let totalHarga = jumlahBarang * hargaBeli;
                jumlahSekarangInput.value = totalHarga.toFixed(2); // Format ke 2 desimal
            }

            // Menambahkan event listener untuk menghitung ulang ketika input berubah
            jumlahBarangInput.addEventListener("input", updateJumlahSekarang);
            hargaBeliInput.addEventListener("input", updateJumlahSekarang);
        });

        function filterTable() {
            let input = document.getElementById("searchInput");
            let filter = input.value.toLowerCase();
            let table = document.getElementById("barangTable");
            let rows = table.getElementsByTagName("tr");

            for (let i = 1; i < rows.length; i++) {
                let cells = rows[i].getElementsByTagName("td");
                let match = false;
                for (let j = 0; j < cells.length; j++) {
                    if (cells[j].innerText.toLowerCase().includes(filter)) {
                        match = true;
                        break;
                    }
                }
                rows[i].style.display = match ? "" : "none";
            }
        }

        document.getElementById("downloadBtn").addEventListener("click", function() {
            let table = document.getElementById("barangTable");
            let rows = Array.from(table.getElementsByTagName("tr"));
            let csv = "";

            // Ambil header (kolom tabel)
            let headerCells = Array.from(rows[0].getElementsByTagName("th"));
            let headerRow = headerCells.map(cell => `"${cell.innerText.replace(/"/g, '""')}"`).join(",");
            csv += headerRow + "\n"; // Menambahkan header ke CSV

            // Loop melalui setiap baris dan ambil data dari sel tabel
            rows.slice(1).forEach((row) => {
                let cells = Array.from(row.getElementsByTagName("td"));
                let rowData = cells.map(cell => `"${cell.innerText.replace(/"/g, '""')}"`).join(",");
                csv += rowData + "\n";
            });

            // Membuat file CSV
            let blob = new Blob([csv], {
                type: "text/csv"
            });
            let link = document.createElement("a");
            link.href = URL.createObjectURL(blob);
            link.download = "data_barang.csv";
            link.click();
        });
    </script>

</body>

</html>