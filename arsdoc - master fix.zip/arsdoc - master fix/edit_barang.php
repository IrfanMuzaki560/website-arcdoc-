<?php
session_start();
include('Koneksi/db_connection.php');

// Buat koneksi
$conn = new mysqli($servername, $username, $password, $database);

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Cek jika ID ada di URL
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Ambil data barang berdasarkan ID
    $sql = "SELECT * FROM barang WHERE id = $id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
    } else {
        echo "<script>alert('Data tidak ditemukan'); window.location.href = 'data.php';</script>";
    }
}

// Cek jika form disubmit
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ambil data dari form
    $nama_barang = $_POST['nama_barang'];
    $jumlah_barang = $_POST['jumlah_barang'];
    $harga_beli = $_POST['harga_beli'];
    $tempat_beli = $_POST['tempat_beli'];
    $tanggal_beli = $_POST['tanggal_beli'];
    $jumlah_sekarang = $_POST['jumlah_sekarang'];

    // Proses upload gambar baru jika ada
    $gambar_nota = $row['gambar_nota']; // Gambar lama
    if (!empty($_FILES['gambar_nota']['name'])) {
        $target_dir = 'F:/uploads';
        $gambar_nota_baru = basename($_FILES['gambar_nota']['name']);
        $target_file = $target_dir . $gambar_nota_baru;

        // Validasi tipe file
        $allowed_types = ['jpg', 'jpeg', 'png', 'gif'];
        $file_type = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
        if (!in_array($file_type, $allowed_types)) {
            echo "<script>alert('Hanya file JPG, JPEG, PNG, dan GIF yang diperbolehkan.');</script>";
        } else {
            // Pindahkan file ke folder tujuan
            if (move_uploaded_file($_FILES['gambar_nota']['tmp_name'], $target_file)) {
                $gambar_nota = $gambar_nota_baru;

                // Hapus gambar lama jika ada
                if (!empty($row['gambar_nota']) && file_exists($target_dir . $row['gambar_nota'])) {
                    unlink($target_dir . $row['gambar_nota']);
                }
            } else {
                echo "<script>alert('Gagal mengunggah gambar.');</script>";
            }
        }
    }

    // Query untuk mengupdate data barang
    $sql = "UPDATE barang SET 
                nama_barang = '$nama_barang', 
                jumlah_barang = '$jumlah_barang', 
                harga_beli = '$harga_beli', 
                tempat_beli = '$tempat_beli', 
                tanggal_beli = '$tanggal_beli', 
                jumlah_sekarang = '$jumlah_sekarang', 
                gambar_nota = '$gambar_nota'
            WHERE id = $id";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Data berhasil diupdate'); window.location.href = 'data.php';</script>";
    } else {
        echo "<script>alert('Error: " . $conn->error . "'); window.location.href = 'index.php';</script>";
    }
}

// Tutup koneksi
$conn->close();
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Edit Barang</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" />
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: flex-start;
            /* Posisi card diatur sedikit ke bawah */
            min-height: 100vh;
            padding-top: 20px;
            /* Tambahkan jarak atas */
        }

        .container {
            width: 100%;
            max-width: 500px;
            /* Lebar container tetap responsif */
            padding: 25px;
            /* Padding diperbesar untuk ruang lebih nyaman */
            margin: 20px auto;
            /* Tambahkan margin untuk jarak dari tepi */
            background-color: #fff;
            border-radius: 10px;
            /* Border radius diperhalus */
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.2);
            /* Bayangan diperbesar */
            min-height: 550px;
            /* Tinggi minimum card */
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        h3 {
            font-size: 22px;
            /* Ukuran font heading diperbesar */
            margin-bottom: 20px;
            text-align: center;
            color: #00796b;
            /* Warna teks heading */
        }

        .form-group label {
            font-weight: 600;
            font-size: 14px;
            margin-bottom: 5px;
            color: #333;
            /* Warna label lebih gelap */
        }

        .form-control {
            border-radius: 5px;
            /* Border radius input diperbesar */
            font-size: 15px;
            padding: 10px;
            border: 1px solid #ddd;
            /* Border warna lembut */
            transition: border-color 0.3s ease-in-out;
            /* Efek hover */
        }

        .form-control:focus {
            border-color: #00796b;
            /* Border saat fokus */
            outline: none;
            /* Hilangkan outline default */
            box-shadow: 0 0 5px rgba(0, 121, 107, 0.5);
            /* Tambahkan efek glow */
        }

        .btn {
            font-size: 15px;
            padding: 10px;
            border-radius: 5px;
            transition: background-color 0.3s ease-in-out;
            /* Animasi hover */
        }

        .btn-primary {
            background-color: rgb(28, 29, 29);
            border-color: rgb(53, 54, 54);
            color: #fff;
        }

        .btn-primary:hover {
            background-color: rgb(76, 77, 76);
            border-color: rgb(102, 102, 102);
            color: #fff;
        }

        .btn-secondary {
            background-color: rgb(66, 74, 78);
            border-color: #b0bec5;
            color: #fff;
        }

        .btn-secondary:hover {
            background-color: #607d8b;
            border-color: #607d8b;
            color: #fff;
        }



        .form-row {
            margin-top: 20px;
        }

        img {
            max-width: 50px;
            /* Gambar tidak terlalu besar */
            height: auto;
            margin-bottom: 15px;
            /* Jarak dengan elemen bawah */
            border: 1px solid #ddd;
            /* Border gambar */
            border-radius: 6px;
        }

        @media (max-width: 576px) {
            .container {
                padding: 15px;
                /* Padding dikurangi di layar kecil */
            }

            h3 {
                font-size: 18px;
                /* Ukuran heading di layar kecil */
            }

            .btn {
                font-size: 14px;
                /* Ukuran tombol lebih kecil di layar kecil */
            }
        }
    </style>

</head>

<body>
    <div class="container">

        <form method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label for="namaBarang">Nama Barang</label>
                <input type="text" class="form-control" id="namaBarang" name="nama_barang" value="<?php echo $row['nama_barang']; ?>" required>
            </div>
            <div class="form-row">
                <div class="form-group col-md-6">
                    <label for="jumlah">Jumlah Barang</label>
                    <input type="number" class="form-control" id="jumlah" name="jumlah_barang" value="<?php echo $row['jumlah_barang']; ?>" required>
                </div>
                <div class="form-group col-md-6">
                    <label for="hargaBeli">Harga Beli</label>
                    <input type="number" class="form-control" id="hargaBeli" name="harga_beli" value="<?php echo $row['harga_beli']; ?>" required>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group col-md-6">
                    <label for="tempatBeli">Tempat Beli</label>
                    <input type="text" class="form-control" id="tempatBeli" name="tempat_beli" value="<?php echo $row['tempat_beli']; ?>" required>
                </div>
                <div class="form-group col-md-6">
                    <label for="tanggalBeli">Tanggal Beli</label>
                    <input type="date" class="form-control" id="tanggalBeli" name="tanggal_beli" value="<?php echo $row['tanggal_beli']; ?>" required>
                </div>
            </div>
            <div class="form-group">
                <label for="jumlahSekarang">Jumlah Sekarang</label>
                <input type="number" class="form-control" id="jumlahSekarang" name="jumlah_sekarang" value="<?php echo $row['jumlah_sekarang']; ?>" required>
            </div>
            <div class="form-group">
                <label for="gambarNota">Gambar Nota</label>
                <?php if (!empty($row['gambar_nota'])): ?>
                    <div>
                        <img src="uploads/<?php echo $row['gambar_nota']; ?>" alt="Gambar Nota" style="width: 100px; height: auto; margin-bottom: 10px;">
                    </div>
                <?php endif; ?>
                <input type="file" class="form-control" id="gambarNota" name="gambar_nota" accept="image/*">
            </div>
            <div class="form-row g-2">
                <div class="col-md-5">
                    <button type="submit" class="btn btn-primary btn-block">Simpan Perubahan</button>
                </div>
                <div class="col-md-5">
                    <a href="data.php" class="btn btn-secondary btn-block">Kembali</a>
                </div>
            </div>
    </div>
    </form>
    </div>
</body>

</html>