<?php
session_start();
include('Koneksi/db_connection.php');

// Buat koneksi
$conn = new mysqli($servername, $username, $password, $database);

// Cek koneksi
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Ambil data dari formulir
$id = intval($_POST['id']);
$user_name = $_POST['user_name'];
$rating = $_POST['rating'];

// Validasi input
if (empty($user_name) || empty($rating)) {
    echo "Nama pengguna dan rating harus diisi.";
    exit;
}

// Update rating di database
$sql = "UPDATE ratings SET user_name = ?, rating = ? WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sii", $user_name, $rating, $id);

if ($stmt->execute()) {
    echo "Penilaian berhasil diperbarui.";
} else {
    echo "Terjadi kesalahan: " . $stmt->error;
}

$stmt->close();
$conn->close();

// Redirect ke halaman laporan
header("Location: reports.php");
exit;
