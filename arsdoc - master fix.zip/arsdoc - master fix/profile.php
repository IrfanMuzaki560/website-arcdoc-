<?php
session_start();
include('Koneksi/db_connection.php');

// Aktifkan error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Cek apakah pengguna sudah login
if (!isset($_SESSION['user_id'])) {
    header("Location: login.html");
    exit();
}

// Ambil ID pengguna dari sesi
$user_id = $_SESSION['user_id'];

// Ambil data pengguna
$sql = "SELECT * FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$stmt->close();
$conn->close();

// Ambil warna dari database
$color = $user['color'] ?? '#00796b'; // Default color if not set
// Ambil URL foto profil
$profile_picture = $user['photo'] ?? 'default.jpg';
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Profil Pengguna</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <style>
        body,
        html {
            height: 100%;
            /* Menetapkan tinggi halaman penuh */
            margin: 0;
            /* Menghilangkan margin default */
            display: flex;
            /* Menggunakan Flexbox untuk menata konten */
            justify-content: center;
            /* Memusatkan konten secara horizontal */
            align-items: center;
            /* Memusatkan konten secara vertikal */
            background-color: #f8f9fa;
            overflow: hidden;
            /* Menghindari halaman digulir */
        }

        .content {
            width: 100%;
            /* Memastikan konten mengisi lebar layar */
            max-width: 900px;
            /* Membatasi lebar maksimal konten 
            padding: 2px;
            lebar bingkai
            background-color: rgba(0, 0, 0, 0.86); */
            background-image: url('uploads/');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            background-attachment: fixed;
            box-sizing: border-box;
            border-radius: 5px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            /* Menghindari scroll pada konten */
        }

        .profile-info {
            max-width: 800px;
            margin: 0 auto;
        }

        .profile-header {
            display: flex;
            align-items: center;
            margin-bottom: 15px;
            background-color: rgba(255, 255, 255, 0.69);
            padding: 15px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .profile-header img {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            object-fit: cover;
            margin-right: 15px;
            border: 4px solid <?= htmlspecialchars($color) ?>;
        }

        .profile-header .profile-header-text h1 {
            font-size: 18px;
            margin-bottom: 5px;
        }

        .profile-header .profile-header-text p {
            font-size: 14px;
            color: #666;
        }

        .edit-profile-btn {
            display: inline-block;
            margin-bottom: 10px;
            background-color: <?= htmlspecialchars($color) ?>;
            color: #ffffff;
            border: none;
            padding: 8px 15px;
            border-radius: 5px;
            font-size: 14px;
            transition: background-color 0.3s;
            max-width: 150px;
            text-align: center;
        }

        .edit-profile-btn:hover {
            background-color: rgb(126, 133, 131);
        }

        .profile-details {
            display: flex;
            flex-direction: column;
            align-items: flex-end;
            margin-left: 5px;
            color: <?= htmlspecialchars($color) ?>;
            font-size: 14px;
            line-height: 1.2;
        }

        .profile-details strong {
            font-size: 12px;
            margin-bottom: 0;
        }

        @media (max-width: 768px) {
            .content {
                margin-left: 0;
                padding: 10px;
            }

            .profile-header {
                flex-direction: column;
                align-items: center;
            }

            .profile-header img {
                width: 100px;
                height: 100px;
            }

            .profile-header h1 {
                font-size: 18px;
            }

            .profile-info .card {
                margin-top: 20px;
            }

            .profile-details {
                text-align: center;
                align-items: center;
            }

            .edit-profile-btn {
                width: 100%;
                max-width: 200px;
            }
        }
    </style>
</head>

<body>
    <div class="content">
        <div class="profile-info">
            <div class="card">
                <div class="card-header text-white" style="background-color: <?= htmlspecialchars($color) ?>;">

                    Informasi Pengguna
                </div>
                <div class="card-body">
                    <!-- Profil Header dengan Gambar dan Info Pengguna -->
                    <div class="profile-header">
                        <img src="uploads/<?= htmlspecialchars($profile_picture) ?>" alt="Profile Picture" class="profile-header-img">
                        <div class="profile-header-text">
                            <h1><?= htmlspecialchars($user['name']) ?></h1>
                            <p>ID: <?= htmlspecialchars($user['id']) ?></p>
                            <p>Email: <?= htmlspecialchars($user['email']) ?></p>
                        </div>
                    </div>

                    <!-- Detail Informasi Pengguna -->
                    <ul class="list-group">
                        <li class="list-group-item">
                            <strong>Username:</strong> <?= htmlspecialchars($user['username'] ?? 'Nama tidak tersedia') ?>
                        </li>
                        <li class="list-group-item">
                            <strong>Email:</strong> <?= htmlspecialchars($user['email'] ?? 'Email tidak tersedia') ?>
                        </li>
                        <li class="list-group-item">
                            <strong>Tanggal Lahir:</strong> <?= htmlspecialchars($user['dob'] ?? 'Tanggal lahir tidak tersedia') ?>
                        </li>
                        <li class="list-group-item">
                            <strong>Alamat:</strong> <?= htmlspecialchars($user['address'] ?? 'Alamat tidak tersedia') ?>
                        </li>
                        <li class="list-group-item">
                            <strong>Bio:</strong> <?= htmlspecialchars($user['bio'] ?? 'Bio tidak tersedia') ?>
                        </li>
                    </ul>

                    <!-- Tombol Edit Profil dan Kembali -->
                    <div class="mt-3">
                        <a href="edit_users.php" class="btn btn-link edit-profile-btn">
                            <i class="fas fa-edit"></i> Edit Profil
                        </a>
                        <a href="index.php" class="btn btn-link edit-profile-btn ml-3">
                            <i class="fas fa-arrow-left"></i> Kembali
                        </a>
                    </div>


                </div>
            </div>
        </div>
    </div>


    <!-- Optional JavaScript -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        // Toggle visibility for the "Password Dokumen" field
        document.getElementById("toggleDocPassword").addEventListener("click", function() {
            var passwordField = document.getElementById("password-doc-field");
            var icon = this;

            // Jika input tipe adalah password, ganti menjadi text, dan sebaliknya
            if (passwordField.type === "password") {
                passwordField.type = "text";
                icon.classList.remove("fa-eye");
                icon.classList.add("fa-eye-slash");
            } else {
                passwordField.type = "password";
                icon.classList.remove("fa-eye-slash");
                icon.classList.add("fa-eye");
            }
        });
    </script>


</body>

</html>