<?php
session_start();
require_once 'Koneksi/db_connection.php';

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Catatan Fitur & Error</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .card {
            width: 100%;
            max-width: 400px;
            border: none;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.82);
            border-radius: 8px;
        }

        .card-header {
            background-color: rgba(0, 0, 0, 0.82);
            color: white;
            text-align: center;
            font-size: 1.2rem;
            font-weight: bold;
            padding: 15px;
            border-top-left-radius: 8px;
            border-top-right-radius: 8px;
        }

        .card-body {
            padding: 20px;
        }

        .btn-primary {
            background-color: rgba(0, 0, 0, 0.82);
            border: none;
            width: 100%;
        }

        .btn-primary:hover {
            background-color: rgb(186, 194, 202);
        }

        .btn-secondary {
            width: 100%;
            margin-top: 10px;
        }

        .table-wrapper {
            margin-top: 20px;
            overflow-x: auto;
        }

        .table {
            width: 100%;
            border-collapse: collapse;
        }

        .table thead th {
            background-color: rgba(0, 0, 0, 0.82);
            color: white;
            text-align: left;
            padding: 10px;
        }

        .table tbody tr:hover {
            background-color: #d7e9f7;
        }

        .table tbody td {
            padding: 10px;
            border: 1px solid #dee2e6;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            body {
                padding: 10px;
                flex-direction: column;
                align-items: stretch;
                justify-content: flex-start;
            }

            .card {
                max-width: 100%;
                margin: 0 auto;
            }

            .card-header {
                font-size: 1rem;
                padding: 10px;
            }

            .card-body {
                padding: 15px;
            }

            .btn-primary,
            .btn-secondary {
                font-size: 0.9rem;
            }

            .table-wrapper {
                margin-top: 10px;
            }

            .table thead th,
            .table tbody td {
                font-size: 0.9rem;
                padding: 8px;
            }
        }
    </style>

</head>

<body>
    <div class="card">
        <div class="card-header">Tambah Catatan</div>
        <div class="card-body">
            <form action="update_note.php" method="post">
                <div class="form-group">
                    <label for="file_name">Study Kasus</label>
                    <input type="text" class="form-control" id="file_name" name="file_name" required>
                </div>
                <div class="form-group">
                    <label for="error_description">Keterangan Error</label>
                    <textarea class="form-control" id="error_description" name="error_description" rows="3" required></textarea>
                </div>
                <div class="form-group">
                    <label for="feature_description">Proses</label>
                    <textarea class="form-control" id="feature_description" name="feature_description" rows="3"></textarea>
                </div>
                <button type="submit" class="btn btn-primary">Tambah Catatan</button>
                <a href="index.php" class="btn btn-secondary">Kembali</a>
            </form>
        </div>
    </div>

    <div class="table-wrapper">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Study Kasus</th>
                    <th>Error</th>
                    <th>Proses</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $sql = "SELECT * FROM project_notes";
                $result = $conn->query($sql);

                if ($result->num_rows == 0) {
                    $default_data = [
                        [
                            'file_name' => 'contoh.html',
                            'error_description' => 'Contoh error',
                            'feature_description' => 'Contoh Proses'
                        ]
                    ];

                    foreach ($default_data as $data) {
                        $stmt = $conn->prepare("INSERT INTO project_notes (file_name, error_description, feature_description) VALUES (?, ?, ?)");
                        $stmt->bind_param("sss", $data['file_name'], $data['error_description'], $data['feature_description']);
                        $stmt->execute();
                        $stmt->close();
                    }

                    $result = $conn->query($sql);
                }

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>
                                <td>" . $row['id'] . "</td>
                                <td>" . $row['file_name'] . "</td>
                                <td>" . $row['error_description'] . "</td>
                                <td>" . $row['feature_description'] . "</td>
                                <td>
                                    <a href='edit_note.php?id=" . $row['id'] . "' class='btn btn-warning btn-sm'>
                                        <i class='fas fa-edit'></i> Edit
                                    </a>

                                </td>
                            </tr>";
                    }
                } else {
                    echo "<tr><td colspan='5' class='text-center'>Tidak ada data</td></tr>";
                }

                $conn->close();
                ?>
            </tbody>
        </table>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>