<?php
session_start();
include('Koneksi/db_connection.php');

// Aktifkan error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Cek apakah pengguna sudah login
if (!isset($_SESSION['user_id'])) {
    header("Location: login.html");
    exit();
}

// Ambil ID pengguna dari sesi
$user_id = $_SESSION['user_id'];

// Ambil data pengguna
$sql = "SELECT * FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$stmt->close();

// Warna default yang diatur di PHP
$default_color = '#00796b';

// Cek apakah form disubmit
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['reset'])) {
        // Reset warna ke default
        $sql = "UPDATE users SET color = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("si", $default_color, $user_id);
        $stmt->execute();
        $stmt->close();
        $message = "Warna telah direset ke default!";
    } else {
        $color = $_POST['color'];
        // Validasi dan simpan warna ke database
        if (preg_match('/^#[0-9A-Fa-f]{6}$/', $color)) {
            $sql = "UPDATE users SET color = ? WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("si", $color, $user_id);
            $stmt->execute();
            $stmt->close();
            $message = "Warna telah diubah!";
        } else {
            $message = "Warna tidak valid!";
        }
    }
}

$conn->close();
$color = $user['color'] ?? $default_color; // Gunakan warna dari database atau warna default
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Pengaturan</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --user-color: <?= htmlspecialchars($color) ?>;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
        }

        .content {
            margin-left: 0px;
            padding: 0px;
            background-color: #ffffff;
            /* White background for the content area */
        }

        .settings-form {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .settings-form h1 {
            margin-bottom: 20px;
            font-size: 24px;
            color: #333;
        }

        .settings-form .form-group {
            margin-bottom: 15px;
        }

        .settings-form .btn {
            background-color: var(--user-color);
            color: #ffffff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            font-size: 16px;
            text-decoration: none;
            transition: background-color 0.3s;
        }

        .settings-form .btn:hover {
            background-color: #80cbc4;
        }

        .settings-form .btn-secondary {
            background-color: #f8f9fa;
            /* Light grey */
            color: var(--user-color);
            border: 1px solid var(--user-color);
        }

        .settings-form .btn-secondary:hover {
            background-color: var(--user-color);
            color: #ffffff;
        }
    </style>
</head>

<body>

    <!-- Content Area -->
    <div class="content">
        <div class="settings-form">
            <h1>Pengaturan Warna</h1>
            <?php if (isset($message)): ?>
                <div class="alert alert-info">
                    <?= htmlspecialchars($message) ?>
                </div>
            <?php endif; ?>
            <form method="post" action="">
                <div class="form-group">
                    <label for="color">Pilih Warna Utama:</label>
                    <input type="color" id="color" name="color" value="<?= htmlspecialchars($user['color'] ?? $default_color) ?>" class="form-control">
                </div>
                <button type="submit" class="btn">Simpan</button>
                <button type="submit" name="reset" class="btn btn-secondary">Reset ke Default</button>
            </form>

            <!-- Kembali ke Index -->
            <div class="mt-4">
                <a href="index.php" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Kembali
                </a>
            </div>
        </div>
    </div>

    <!-- Optional JavaScript -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>