<?php
session_start();
include('Koneksi/db_connection.php');

// Buat koneksi
$conn = new mysqli($servername, $username, $password, $database);
// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Cek jika ID ada di URL
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Query untuk menghapus data barang berdasarkan ID
    $sql = "DELETE FROM barang WHERE id = $id";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Data berhasil dihapus'); window.location.href = 'data.php';</script>";
    } else {
        echo "<script>alert('Error: " . $conn->error . "'); window.location.href = 'data.php';</script>";
    }
} else {
    echo "<script>alert('ID tidak ditemukan'); window.location.href = 'data.php';</script>";
}

// Tutup koneksi
$conn->close();
