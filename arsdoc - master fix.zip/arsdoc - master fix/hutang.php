<?php
session_start();
include('Koneksi/db_connection.php');

// Buat koneksi
$conn = new mysqli($servername, $username, $password, $database);
// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Cek jika user_id sudah ada di sesi (user harus login)
if (!isset($_SESSION['user_id'])) {
    die("Harap login terlebih dahulu.");
}
$user_id = $_SESSION['user_id']; // Ambil user_id pengguna yang sedang login

// Cek jika form disubmit
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ambil data dari form dan lakukan validasi
    $nama_hutang = isset($_POST['nama_hutang']) ? $_POST['nama_hutang'] : '';
    $jumlah_hutang = isset($_POST['jumlah_hutang']) ? $_POST['jumlah_hutang'] : '';
    $tanggal_jatuh_tempo = isset($_POST['tanggal_jatuh_tempo']) ? $_POST['tanggal_jatuh_tempo'] : '';
    $nama_pemberi_hutang = isset($_POST['nama_pemberi_hutang']) ? $_POST['nama_pemberi_hutang'] : '';
    $status_pembayaran = isset($_POST['status_pembayaran']) ? $_POST['status_pembayaran'] : '';
    $keterangan_hutang = isset($_POST['keterangan_hutang']) ? $_POST['keterangan_hutang'] : ''; // Ambil keterangan hutang

    // Validasi input
    if (empty($nama_hutang) || empty($jumlah_hutang) || empty($tanggal_jatuh_tempo) || empty($nama_pemberi_hutang) || empty($status_pembayaran)) {
        echo "<script>alert('Semua field harus diisi.');</script>";
    } else {
        // Query untuk menyimpan data hutang menggunakan prepared statements dan menambahkan user_id
        $stmt = $conn->prepare("INSERT INTO hutang (nama_hutang, jumlah_hutang, tanggal_jatuh_tempo, nama_pemberi_hutang, status_pembayaran, keterangan_hutang, user_id) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssssi", $nama_hutang, $jumlah_hutang, $tanggal_jatuh_tempo, $nama_pemberi_hutang, $status_pembayaran, $keterangan_hutang, $user_id);

        if ($stmt->execute()) {
            echo "<script>alert('Data berhasil disimpan');</script>";
        } else {
            echo "<script>alert('Error: " . $stmt->error . "');</script>";
        }

        // Menutup statement setelah eksekusi
        $stmt->close();
    }
}

// Query untuk mengambil data hutang berdasarkan user_id
$sql = "SELECT * FROM hutang WHERE user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id); // Bind user_id ke query
$stmt->execute();
$result = $stmt->get_result();

// Tutup koneksi
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Catatan Hutang</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" />
    <link rel="stylesheet" href="styles.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" />
    <style>
        /* Style customization */
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            height: 100vh;
            display: flex;
            flex-direction: column;
        }

        .container {
            flex: 1;
            margin-top: 80px;
            padding-bottom: 20px;
        }

        .card {
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .card-header {
            background-color: rgba(1, 13, 24, 0.81);
            color: #ffffff;
            font-weight: bold;
        }

        .form-group label {
            font-weight: bold;
        }

        .table {
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .table thead th {
            background-color: rgba(1, 13, 24, 0.81);
            color: white;
            font-size: 14px;
        }

        .table tbody tr:nth-child(even) {
            background-color: #f1f1f1;
        }

        .table tbody tr:hover {
            background-color: #b2dfdb;
        }

        .input-group-text {
            background-color: rgba(1, 13, 24, 0.81);
            color: white;
        }

        .btn-success {
            background-color: #80cbc4;
            border-color: #80cbc4;
        }

        .btn-success:hover {
            background-color: #004d40;
            border-color: #004d40;
        }

        @media (max-width: 768px) {
            .form-inline {
                flex-direction: column;
                align-items: stretch;
            }

            .navbar-collapse {
                flex-direction: column;
            }

            .table {
                font-size: 12px;
            }
        }
    </style>
</head>

<body>

    <!-- Content Area -->
    <div class="container mt-5 pt-4">

        <!-- Form Input Hutang -->
        <div class="card mb-4">
            <div class="card-header">Tambah Hutang</div>
            <div class="card-body">
                <form id="hutangForm" method="post">
                    <div class="form-group">
                        <label for="namaHutang">Nama Hutang</label>
                        <input type="text" class="form-control" id="namaHutang" name="nama_hutang" required>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-3">
                            <label for="jumlahHutang">Jumlah Hutang</label>
                            <input type="number" class="form-control" id="jumlahHutang" name="jumlah_hutang" required>
                        </div>
                        <div class="form-group col-md-3">
                            <label for="tanggalJatuhTempo">Tanggal Jatuh Tempo</label>
                            <input type="date" class="form-control" id="tanggalJatuhTempo" name="tanggal_jatuh_tempo" required>
                        </div>
                        <div class="form-group col-md-3">
                            <label for="namaPemberiHutang">Nama Pemberi Hutang</label>
                            <input type="text" class="form-control" id="namaPemberiHutang" name="nama_pemberi_hutang" required>
                        </div>
                        <div class="form-group col-md-3">
                            <label for="statusPembayaran">Status Pembayaran</label>
                            <select class="form-control" id="statusPembayaran" name="status_pembayaran" required>
                                <option value="Belum Dibayar">Belum Dibayar</option>
                                <option value="Sudah Dibayar">Sudah Dibayar</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="keteranganHutang">Keterangan Hutang</label>
                        <textarea class="form-control" id="keteranganHutang" name="keterangan_hutang" rows="3"></textarea>
                    </div>
                    <!-- Tombol Simpan Data -->
                    <button type="submit" class="btn btn-success">
                        <i class="fas fa-save"></i> Simpan Data
                    </button>

                    <!-- Tombol Kembali -->
                    <a href="index.php" class="btn btn-secondary">
                        <i class="fas fa-arrow-left"></i> Kembali
                    </a>

                </form>
            </div>
        </div>

        <!-- Search and Download Controls -->
        <div class="mb-3">
            <div class="form-inline">
                <!-- Input Search -->
                <div class="input-group mr-2">
                    <div class="input-group-prepend">
                        <span class="input-group-text"><i class="fas fa-search"></i></span>
                    </div>
                    <input type="text" id="searchInput" class="form-control" placeholder="Cari hutang..." onkeyup="filterTable()">
                </div>

                <!-- Dropdown untuk memilih kategori pencarian -->
                <div class="input-group">
                    <select id="searchCriteria" class="form-control" onchange="filterTable()">
                        <option value="nama_hutang">Nama Hutang</option>
                        <option value="nama_pemberi_hutang">Nama Pemberi Hutang</option>
                        <option value="tanggal_jatuh_tempo">Tanggal Jatuh Tempo</option>
                    </select>
                </div>
            </div>

            <!-- Tombol Download CSV -->
            <button id="downloadBtn" class="btn btn-success mt-2" onclick="downloadCSV()">
                <i class="fas fa-file-download"></i> Download CSV
            </button>
        </div>

        <!-- Tabel Hutang -->
        <div class="table-responsive">
            <table class="table table-striped" id="hutangTable">
                <thead>
                    <tr>
                        <th>Nama</th>
                        <th>Total</th>
                        <th>Tanggal</th>
                        <th>Penyedia</th>
                        <th>Status</th>
                        <th>Keterangan</th> <!-- Added Keterangan Hutang -->
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr>
                <td>" . $row['nama_hutang'] . "</td>
                <td>" . $row['jumlah_hutang'] . "</td>
                <td>" . $row['tanggal_jatuh_tempo'] . "</td>
                <td>" . $row['nama_pemberi_hutang'] . "</td>
                <td>" . $row['status_pembayaran'] . "</td>
                <td>" . $row['keterangan_hutang'] . "</td> <!-- Display Keterangan Hutang -->
                <td>
                    <a href='edit_hutang.php?id=" . $row['id'] . "' class='btn btn-warning btn-sm'>
                        <i class='fas fa-edit'></i> Edit
                    </a>
                    <a href='delete_hutang.php?id=" . $row['id'] . "' class='btn btn-danger btn-sm'>
                        <i class='fas fa-trash'></i> Hapus
                    </a>
                </td>
              </tr>";
                        }
                    }
                    ?>

                </tbody>
            </table>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        function filterTable() {
            let searchInput = document.getElementById('searchInput').value.toLowerCase();
            let searchCriteria = document.getElementById('searchCriteria').value;
            let rows = document.getElementById('hutangTable').getElementsByTagName('tr');

            for (let i = 1; i < rows.length; i++) {
                let cell = rows[i].querySelector(`td:nth-child(${searchCriteria === 'nama_hutang' ? 1 : searchCriteria === 'nama_pemberi_hutang' ? 4 : searchCriteria === 'keterangan_hutang' ? 6 : 3})`);
                if (cell) {
                    let text = cell.textContent.toLowerCase();
                    rows[i].style.display = text.indexOf(searchInput) > -1 ? '' : 'none';
                }
            }
        }

        function downloadCSV() {
            let csv = [];
            let rows = document.querySelectorAll("#hutangTable tr");
            for (let i = 0; i < rows.length; i++) {
                let cols = rows[i].querySelectorAll("td, th");
                let data = [];
                for (let j = 0; j < cols.length; j++) {
                    data.push(cols[j].textContent);
                }
                csv.push(data.join(","));
            }
            let csvString = csv.join("\n");
            let a = document.createElement("a");
            a.href = "data:text/csv;charset=utf-8," + encodeURIComponent(csvString);
            a.target = "_blank";
            a.download = "hutang.csv";
            a.click();
        }
    </script>
</body>

</html>