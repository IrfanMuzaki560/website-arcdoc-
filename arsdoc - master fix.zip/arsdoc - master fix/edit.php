<?php
session_start();
include('Koneksi/db_connection.php');

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Ambil data dokumen
    $query = "SELECT * FROM documents WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $document = $result->fetch_assoc();

    if ($document) {
        // Formulir untuk mengedit dokumen
        echo '<form id="editForm" action="index.php" method="post">';
        echo '<input type="hidden" name="action" value="update">';
        echo '<input type="hidden" name="id" value="' . htmlspecialchars($document['id']) . '">';
        echo '<div class="form-group">';
        echo '<label for="editTitle">Judul Dokumen</label>';
        echo '<input type="text" class="form-control" id="editTitle" name="editTitle" value="' . htmlspecialchars($document['title']) . '" required />';
        echo '</div>';
        echo '<div class="form-group">';
        echo '<label for="editDescription">Deskripsi Dokumen</label>';
        echo '<textarea class="form-control" id="editDescription" name="editDescription" rows="3" required>' . htmlspecialchars($document['description']) . '</textarea>';
        echo '</div>';
        echo '<button type="submit" class="btn btn-secondary">
             <i class="fas fa-save"></i> Simpan Perubahan
             </button>';
        echo '</form>';
    } else {
        echo 'Dokumen tidak ditemukan.';
    }

    $stmt->close();
    $conn->close();
}
