<?php
// register_process.php

// Koneksi database
include('Koneksi/db_connection.php');

// Ambil data dari formulir
$username = $_POST['username'];
$email = $_POST['email'];
$password = password_hash($_POST['password'], PASSWORD_BCRYPT); // Enkripsi password

// Periksa apakah username atau email sudah ada
$query = "SELECT * FROM users WHERE username = ? OR email = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("ss", $username, $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // Username atau email sudah ada
    echo '<script>alert("Username atau email sudah terdaftar."); window.location.href="register.html";</script>';
} else {
    // Masukkan data pengguna baru
    $query = "INSERT INTO users (username, email, password) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("sss", $username, $email, $password);

    if ($stmt->execute()) {
        // Pendaftaran berhasil, arahkan ke halaman login
        echo '<script>alert("Pendaftaran berhasil. Silakan login."); window.location.href="login.html";</script>';
    } else {
        // Pendaftaran gagal
        echo '<script>alert("Pendaftaran gagal. Silakan coba lagi."); window.location.href="register.html";</script>';
    }
}
