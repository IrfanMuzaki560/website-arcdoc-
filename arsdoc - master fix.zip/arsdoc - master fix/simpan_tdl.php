<?php
include('Koneksi/db_connection.php'); // Pastikan koneksi sudah benar
session_start(); // Memulai sesi untuk mendapatkan user_id

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validasi apakah user_id tersedia di sesi
    if (!isset($_SESSION['user_id'])) {
        die("User tidak terautentikasi. Silakan login terlebih dahulu.");
    }

    $user_id = $_SESSION['user_id']; // Ambil user_id dari sesi

    // Ambil data dari form dengan validasi sederhana
    $nama = isset($_POST['nama']) ? $conn->real_escape_string(trim($_POST['nama'])) : '';
    $hari = isset($_POST['hari']) ? $conn->real_escape_string(trim($_POST['hari'])) : '';
    $tanggal = isset($_POST['tanggal']) ? $conn->real_escape_string(trim($_POST['tanggal'])) : '';
    $start_jam = isset($_POST['start_jam']) ? $conn->real_escape_string(trim($_POST['start_jam'])) : '';
    $selesai_jam = isset($_POST['selesai_jam']) ? $conn->real_escape_string(trim($_POST['selesai_jam'])) : '';
    $proses = isset($_POST['proses']) ? $conn->real_escape_string(trim($_POST['proses'])) : '';

    // Validasi jika salah satu input kosong
    if (empty($nama) || empty($hari) || empty($tanggal) || empty($_POST['kegiatan'])) {
        die("Semua kolom wajib diisi.");
    }

    // Simpan kegiatan (jika ada lebih dari satu kegiatan)
    $kegiatan_array = $_POST['kegiatan']; // Karena kegiatan adalah array
    foreach ($kegiatan_array as $kegiatan) {
        $kegiatan = $conn->real_escape_string(trim($kegiatan));

        // Query SQL untuk menyimpan setiap kegiatan
        $sql = "INSERT INTO tdl (nama, hari, tanggal, kegiatan, start_jam, selesai_jam, proses, user_id) 
                VALUES ('$nama', '$hari', '$tanggal', '$kegiatan', '$start_jam', '$selesai_jam', '$proses', '$user_id')";

        // Eksekusi query dan cek hasilnya
        if (!$conn->query($sql)) {
            echo "Terjadi kesalahan saat menyimpan: " . $conn->error;
            exit;
        }
    }

    // Redirect ke halaman utama setelah sukses
    header("Location: tdl.php");
    exit();
} else {
    echo "Akses tidak valid.";
}
