
<?php
session_start();

// Pastikan file koneksi ada
require_once __DIR__ . "/Koneksi/db_connection.php";

// Pastikan koneksi database berhasil sebelum lanjut ke query
if (!isset($conn)) {
    die("Koneksi database tidak tersedia.");
}

// Koneksi berhasil, bisa lanjut ke query database



if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Ambil data dokumen berdasarkan ID
    $query = "SELECT * FROM documents WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $document = $result->fetch_assoc();

    if ($document) {
        // Pastikan user sudah login untuk mengambil username
        if (!isset($_SESSION['username'])) {
            echo 'User tidak login.';
            exit();
        }

        $username = $_SESSION['username']; // Username dari session
        $uploadDate = date('Y-m-d', strtotime($document['created_at'])); // Tanggal unggah

        // Ambil ukuran file dari database
        $fileSizeBytes = $document['file_size'];
        $fileSizeKB = round($fileSizeBytes / 1024, 2); // Ukuran dalam KB
        $fileSizeMB = round($fileSizeBytes / (1024 * 1024), 2); // Ukuran dalam MB

        // Tampilkan detail dokumen
        echo '<h4>Judul: ' . htmlspecialchars($document['title']) . '</h4>';
        echo '<p>Deskripsi: ' . htmlspecialchars($document['description']) . '</p>';
        echo '<p>Nama File: ' . htmlspecialchars($document['file_name']) . '</p>';
        echo '<p>Tipe File: ' . htmlspecialchars($document['file_type']) . '</p>';
        echo '<p>Ukuran File: ' . $fileSizeKB . ' KB (' . $fileSizeMB . ' MB)</p>';
        echo '<p>Tanggal Unggah: ' . htmlspecialchars($document['created_at']) . '</p>';
    } else {
        echo 'Dokumen tidak ditemukan.';
    }

    $stmt->close();
    $conn->close();
} else {
    echo 'ID dokumen tidak diberikan.';
}
