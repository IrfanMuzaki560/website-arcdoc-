<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Website Arsip Dokumen</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet" />
    <style>
        /* Hero Section */
        .hero-section {
            background-color: #004d40;
            color: white;
            padding: 60px 20px;
        }

        .hero-section h1 {
            font-size: 2.5rem;
            font-weight: bold;
        }

        .hero-section p {
            font-size: 1.2rem;
        }

        .hero-section .btn-custom {
            background-color: #80cbc4;
            border: none;
            color: #fff;
            padding: 10px 20px;
            border-radius: 5px;
        }

        .hero-section .btn-custom:hover {
            background-color: #005f54;
        }

        /* Feature Box */
        .feature-box {
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            padding: 20px;
            background-color: #ffffff;
            transition: transform 0.3s ease-in-out;
            text-align: center;
        }

        .feature-box:hover {
            transform: translateY(-10px);
        }

        .feature-box i {
            font-size: 40px;
            color: #004d40;
            margin-bottom: 10px;
        }

        /* Input Modal */
        .form-control {
            border-radius: 8px;
        }

        .modal-content {
            border-radius: 10px;
        }

        .modal-header {
            background-color: #004d40;
            color: white;
        }

        /* Footer */
        footer {
            background-color: #004d40;
            color: white;
            padding: 20px 0;
        }

        /* Responsiveness */
        @media (max-width: 768px) {
            .hero-section h1 {
                font-size: 2rem;
            }

            .hero-section p {
                font-size: 1rem;
            }

            .feature-box {
                margin-bottom: 20px;
            }
        }
    </style>
</head>

<body>
    <!-- Hero Section -->
    <section class="hero-section text-center">
        <div class="container">
            <h1><i class="bi bi-journal-bookmark-fill"></i> Selamat Datang di Website Arsip Dokumen</h1>
            <p>Kelola dokumen Anda dengan mudah dan efisien.</p>
            <div class="d-flex flex-column flex-md-row justify-content-center mt-4">
                <a href="index.php" class="btn btn-custom btn-lg mb-3 mb-md-0 mx-md-2">
                    Arsip Dokumen <i class="bi bi-file-earmark-text-fill"></i>
                </a>
                <button class="btn btn-custom btn-lg mx-md-2" data-toggle="modal" data-target="#inputBarangModal">
                    <i class="bi bi-box"></i> Input Data Barang
                </button>
            </div>
        </div>
    </section>

    <!-- Modal Input Barang -->
    <div class="modal fade" id="inputBarangModal" tabindex="-1" role="dialog" aria-labelledby="inputBarangModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="inputBarangModalLabel"><i class="bi bi-box"></i> Input Data Barang</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form method="POST">
                        <div class="form-group">
                            <label for="namaBarang"><i class="bi bi-card-list"></i> Nama Barang</label>
                            <input type="text" class="form-control" id="namaBarang" name="nama_barang" required />
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="jumlahBarang"><i class="bi bi-hash"></i> Jumlah Barang</label>
                                <input type="number" class="form-control" id="jumlahBarang" name="jumlah_barang" required />
                            </div>
                            <div class="form-group col-md-6">
                                <label for="hargaBeli"><i class="bi bi-currency-dollar"></i> Harga Beli</label>
                                <input type="number" class="form-control" id="hargaBeli" name="harga_beli" required />
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="tempatBeli"><i class="bi bi-shop"></i> Tempat Beli</label>
                                <input type="text" class="form-control" id="tempatBeli" name="tempat_beli" required />
                            </div>
                            <div class="form-group col-md-6">
                                <label for="tanggalBeli"><i class="bi bi-calendar-event"></i> Tanggal Beli</label>
                                <input type="date" class="form-control" id="tanggalBeli" name="tanggal_beli" required />
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="jumlahSekarang"><i class="bi bi-boxes"></i> Jumlah Sekarang</label>
                            <input type="number" class="form-control" id="jumlahSekarang" name="jumlah_sekarang" required />
                        </div>
                        <button type="submit" class="btn btn-custom btn-block">
                            <i class="bi bi-save"></i> Simpan Data Barang
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Fitur Utama -->
    <section class="container my-5">
        <h2 class="text-center mb-5"><i class="bi bi-star-fill"></i> Fitur Utama</h2>
        <div class="row">
            <div class="col-lg-4 col-md-6 mb-4">
                <div class="feature-box">
                    <i class="bi bi-file-earmark-text-fill"></i>
                    <h5>Manajemen Arsip</h5>
                    <p>Kelola dan temukan dokumen Anda dengan mudah.</p>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 mb-4">
                <div class="feature-box">
                    <i class="bi bi-cloud-upload"></i>
                    <h5>Upload Dokumen</h5>
                    <p>Upload dokumen Anda ke platform kami dengan cepat.</p>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 mb-4">
                <div class="feature-box">
                    <i class="bi bi-search"></i>
                    <h5>Pencarian Cepat</h5>
                    <p>Cari dokumen Anda dalam sekejap dengan fitur pencarian.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="text-center">
        <p>&copy; 2025 Website Arsip Dokumen. Semua hak dilindungi.</p>
    </footer>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.0/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>