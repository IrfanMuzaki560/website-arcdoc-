<?php
session_start();

// Cek apakah pengguna sudah login
if (!isset($_SESSION['user_id'])) {
    header("Location: login.html");
    exit();
}

// Ambil data pengguna dari sesi
$user_id = $_SESSION['user_id'];

// Koneksi ke database
include('Koneksi/db_connection.php');

// Query untuk mengambil data pengguna berdasarkan ID
$query = "SELECT username FROM users WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$stmt->bind_result($username);
$stmt->fetch();
$stmt->close();

// Cek apakah pengguna yang sedang login adalah "Irfan"
if ($username !== 'Irfan') {
    echo "
    <div class='alert alert-danger alert-dismissible fade show' role='alert'>
        <strong>Gagal!</strong> Anda tidak memiliki izin untuk menghapus akun.
        <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
            <span aria-hidden='true'>&times;</span>
        </button>
    </div>";
    echo "<script>
        setTimeout(function() {
            window.location.href = 'users.php';
        }, 5000);  // Arahkan ke users.php setelah 5 detik
    </script>";
    exit();
}

// Cek apakah pengguna yang sedang login mencoba menghapus akun mereka sendiri
if (isset($_GET['id']) && $_GET['id'] == $user_id) {
    echo "
    <div class='alert alert-danger alert-dismissible fade show' role='alert'>
        <strong>Gagal!</strong> Anda tidak bisa menghapus akun yang sedang aktif.
        <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
            <span aria-hidden='true'>&times;</span>
        </button>
    </div>";
    echo "<script>
        setTimeout(function() {
            window.location.href = 'users.php';
        }, 5000);  // Arahkan ke users.php setelah 5 detik
    </script>";
    exit();
}

// Query untuk menghapus pengguna dari database
$query = "DELETE FROM users WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $_GET['id']);  // Menggunakan ID pengguna yang ingin dihapus

if ($stmt->execute()) {
    echo "
    <div class='alert alert-success alert-dismissible fade show' role='alert'>
        <strong>Berhasil!</strong> Akun berhasil dihapus.
        <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
            <span aria-hidden='true'>&times;</span>
        </button>
    </div>";
    echo "<script>
        setTimeout(function() {
            window.location.href = 'users.php';
        }, 1);  // Arahkan ke users.php setelah 1 detik
    </script>";
    exit();
} else {
    echo "
    <div class='alert alert-danger alert-dismissible fade show' role='alert'>
        <strong>Gagal!</strong> Tidak dapat menghapus profil. Silakan coba lagi nanti.
        <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
            <span aria-hidden='true'>&times;</span>
        </button>
    </div>";
    echo "<script>
        setTimeout(function() {
            window.location.href = 'users.php';
        }, 1);  // Arahkan ke users.php setelah 1 detik
    </script>";
}
