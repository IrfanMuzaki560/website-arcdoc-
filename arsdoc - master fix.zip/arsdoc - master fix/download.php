<?php
session_start();
include('Koneksi/db_connection.php');

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $password = isset($_POST['password']) ? $_POST['password'] : null;

    // Ambil data dokumen
    $query = "SELECT file_name, file_type, password, file_content FROM documents WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $document = $result->fetch_assoc();

    if ($document) {
        // Verifikasi password jika diperlukan
        if ($document['password']) {
            if (!$password) {
                // Tampilkan form password jika password tidak diberikan
                echo '
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verifikasi Password</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { font-family: Arial, sans-serif; background-color: #f8f9fa; }
        .container { max-width: 350px; margin: 100px auto; padding: 20px; background-color: #ffffff; border-radius: 8px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); }
        h2 { color: #00796b; text-align: center; margin-bottom: 20px; font-size: 18px; }
        .form-group label { font-weight: bold; }
        .btn-primary { background-color: #00796b; border-color: #00796b; font-size: 14px; padding: 10px 20px; }
        .btn-primary:hover { background-color: #004d40; border-color: #004d40; }
        .alert { margin-bottom: 20px; color: #dc3545; font-size: 14px; }
        .btn-secondary { background-color: #6c757d; border-color: #6c757d; font-size: 14px; padding: 10px 20px; }
        .button-group { display: flex; justify-content: space-between; }
        .button-group .btn { width: 48%; }
    </style>
</head>
<body>
    <div class="container">
        <h2>Masukkan Password</h2>
        <form method="post">
            <input type="hidden" name="id" value="' . htmlspecialchars($id) . '">
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" name="password" id="password" class="form-control" placeholder="Masukkan password" required>
            </div>
            <div class="button-group">
                <button type="submit" class="btn btn-primary">Submit</button>
                <a href="index.php" class="btn btn-secondary">Kembali</a>
            </div>
        </form>
    </div>
</body>
</html>';
                exit();
            } elseif (!password_verify($password, $document['password'])) {
                // Tampilkan pesan kesalahan jika password salah
                echo '
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verifikasi Password</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { font-family: Arial, sans-serif; background-color: #f8f9fa; }
        .container { max-width: 350px; margin: 100px auto; padding: 20px; background-color: #ffffff; border-radius: 8px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); }
        h2 { color: #dc3545; text-align: center; margin-bottom: 20px; font-size: 18px; }
        .form-group label { font-weight: bold; }
        .alert { margin-bottom: 20px; color: #dc3545; font-size: 14px; }
        .button-group { display: flex; justify-content: space-between; }
        .button-group .btn { width: 48%; }
    </style>
</head>
<body>
    <div class="container">
        <h2>Password Tidak Valid</h2>
        <p class="alert">Password yang Anda masukkan tidak valid.</p>
        <form method="post">
            <input type="hidden" name="id" value="' . htmlspecialchars($id) . '">
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" name="password" id="password" class="form-control" placeholder="Masukkan password" required>
            </div>
            <div class="button-group">
                <button type="submit" class="btn btn-primary">Submit</button>
                <a href="index.php" class="btn btn-secondary">Kembali</a>
            </div>
        </form>
    </div>
</body>
</html>';
                exit();
            }
        }

        // Jika password valid atau dokumen tidak memiliki password, lanjutkan dengan pengunduhan file dari database
        $fileContent = $document['file_content'];
        $fileType = $document['file_type'];
        $fileName = $document['file_name'];

        // Set headers for file download
        header('Content-Description: File Transfer');
        header('Content-Type: ' . $fileType);
        header('Content-Disposition: attachment; filename="' . $fileName . '"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . strlen($fileContent));

        // Output file content
        echo $fileContent;
        exit();
    } else {
        echo 'Dokumen tidak ditemukan.';
    }
}
