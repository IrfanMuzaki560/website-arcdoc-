<?php
include 'Koneksi/db_connection.php';

$email = isset($_POST['email']) ? $_POST['email'] : '';
$newPassword = isset($_POST['new_password']) ? $_POST['new_password'] : '';

function processResetPassword($conn, $email, $newPassword)
{
    // Mengecek apakah email ada di database
    $sql = "SELECT id FROM users WHERE email = ?";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        die("Prepare statement failed: " . $conn->error);
    }

    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Email valid, lanjutkan untuk memperbarui password
        $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);

        $sql = "UPDATE users SET password = ? WHERE email = ?";
        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            die("Prepare statement failed: " . $conn->error);
        }

        $stmt->bind_param("ss", $hashedPassword, $email);
        $stmt->execute();

        echo "<script>
            alert('Password Anda telah diperbarui.');
            window.location.href = 'login.html';
        </script>";
    } else {
        echo "<script>
            alert('Email tidak ditemukan.');
            window.location.href = 'forgot_password.php';
        </script>";
    }

    $stmt->close();
}

processResetPassword($conn, $email, $newPassword);
$conn->close();
