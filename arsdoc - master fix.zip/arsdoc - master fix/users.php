<?php
session_start();
include('Koneksi/db_connection.php');

// Buat koneksi
$conn = new mysqli($servername, $username, $password, $database);
// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Cek jika form disubmit
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ambil data dari form dan lakukan validasi
    $username = isset($_POST['username']) ? $_POST['username'] : '';
    $email = isset($_POST['email']) ? $_POST['email'] : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';
    $address = isset($_POST['address']) ? $_POST['address'] : ''; // Ambil data alamat

    // Validasi input
    if (empty($username) || empty($email) || empty($password) || empty($address)) {
        echo "<script>alert('Semua field harus diisi.');</script>";
    } else {
        // Hash password untuk keamanan
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        // Query untuk menyimpan data pengguna
        $sql = "INSERT INTO users (username, email, password, address) VALUES ('$username', '$email', '$hashedPassword', '$address')";

        if ($conn->query($sql) === TRUE) {
            echo "<script>alert('Data pengguna berhasil disimpan');</script>";
        } else {
            echo "<script>alert('Error: " . $sql . "<br>" . $conn->error . "');</script>";
        }
    }
}

// Query untuk mengambil data pengguna
$sql = "SELECT * FROM users";
$result = $conn->query($sql);

// Tutup koneksi
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Tambah Pengguna</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" />
    <link rel="stylesheet" href="styles.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" />
    <style>
        /* Style customization */
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            height: 100vh;
            display: flex;
            flex-direction: column;
        }

        .container {
            flex: 1;
            margin-top: 80px;
            padding-bottom: 20px;
        }

        .card {
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .card-header {
            background-color: rgba(1, 13, 24, 0.81);
            color: #ffffff;
            font-weight: bold;
        }

        .form-group label {
            font-weight: bold;
        }

        .table {
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .table thead th {
            background-color: rgba(1, 13, 24, 0.81);
            color: white;
            font-size: 14px;
        }

        .table tbody tr:nth-child(even) {
            background-color: #f1f1f1;
        }

        .table tbody tr:hover {
            background-color: #b2dfdb;
        }

        .input-group-text {
            background-color: rgba(1, 13, 24, 0.81);
            color: white;
        }

        .btn-success {
            background-color: #80cbc4;
            border-color: #80cbc4;
        }

        .btn-success:hover {
            background-color: #004d40;
            border-color: #004d40;
        }

        @media (max-width: 768px) {
            .form-inline {
                flex-direction: column;
                align-items: stretch;
            }

            .navbar-collapse {
                flex-direction: column;
            }

            .table {
                font-size: 12px;
            }
        }
    </style>
</head>

<body>

    <!-- Content Area -->
    <div class="container mt-5 pt-4">

        <!-- Form Input Pengguna -->
        <div class="card mb-4">
            <div class="card-header">Tambah Pengguna</div>
            <div class="card-body">
                <form id="penggunaForm" method="post">
                    <div class="form-group">
                        <label for="id">ID</label>
                        <input type="text" class="form-control" id="username" name="username" required>
                    </div>
                    <div class="form-group">
                        <label for="username">Nama Pengguna</label>
                        <input type="text" class="form-control" id="username" name="username" required>
                    </div>
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" class="form-control" id="email" name="email" required>
                    </div>
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                    </div>
                    <div class="form-group">
                        <label for="address">Alamat</label>
                        <input type="text" class="form-control" id="address" name="address" required>
                    </div>
                    <!-- Tombol Simpan Data -->
                    <button type="submit" class="btn btn-success">
                        <i class="fas fa-save"></i> Simpan Data
                    </button>

                    <!-- Tombol Kembali -->
                    <a href="index.php" class="btn btn-secondary">
                        <i class="fas fa-arrow-left"></i> Kembali
                    </a>
                </form>
            </div>
        </div>

        <!-- Tabel Pengguna -->
        <div class="table-responsive">
            <table class="table table-striped" id="penggunaTable">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nama Pengguna</th>
                        <th>Email</th>
                        <th>Alamat</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr>
                                <td>{$row['id']}</td>
                                <td>{$row['username']}</td>
                                <td>{$row['email']}</td>
                                <td>{$row['address']}</td>
                                <td>
                                    <a href='edit_users.php?id={$row['id']}' class='btn btn-warning btn-sm'>
                                        <i class='fas fa-edit'></i> Edit
                                    </a>
                                    <a href='delete_users.php?id={$row['id']}' class='btn btn-danger btn-sm'>
                                    <i class='fas fa-trash-alt'></i> Hapus
                                    </a>


                                </td>
                            </tr>";
                        }
                    } else {
                        echo "<tr><td colspan='4' class='text-center'>Tidak ada data</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>

</body>

</html>