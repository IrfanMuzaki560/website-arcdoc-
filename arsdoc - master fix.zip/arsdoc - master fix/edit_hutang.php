<?php
session_start();
include('Koneksi/db_connection.php'); // Pastikan file ini berisi koneksi yang benar

// Cek apakah ID ada dalam URL
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Ambil data berdasarkan ID
    $sql = "SELECT * FROM hutang WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $data = $result->fetch_assoc();

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Ambil data dari form
        $nama_hutang = $_POST['nama_hutang'];
        $jumlah_hutang = $_POST['jumlah_hutang'];
        $tanggal_jatuh_tempo = $_POST['tanggal_jatuh_tempo'];
        $nama_pemberi_hutang = $_POST['nama_pemberi_hutang'];
        $status_pembayaran = $_POST['status_pembayaran'];
        $keterangan_hutang = $_POST['keterangan_hutang']; // Tambahkan field keterangan_hutang

        // Update data di database
        $sql_update = "UPDATE hutang SET nama_hutang = ?, jumlah_hutang = ?, tanggal_jatuh_tempo = ?, nama_pemberi_hutang = ?, status_pembayaran = ?, keterangan_hutang = ? WHERE id = ?";
        $stmt_update = $conn->prepare($sql_update);

        // Bind the parameters correctly
        // Assuming jumlah_hutang is a decimal/float and id is an integer
        $stmt_update->bind_param(
            "sdsssss",
            $nama_hutang,
            $jumlah_hutang,
            $tanggal_jatuh_tempo,
            $nama_pemberi_hutang,
            $status_pembayaran,
            $keterangan_hutang,
            $id
        ); // Ensure we have the right number of arguments

        if ($stmt_update->execute()) {
            echo "<script>alert('Data berhasil diupdate'); window.location.href='hutang.php';</script>";
        } else {
            echo "<script>alert('Error: " . $stmt_update->error . "');</script>";
        }
    }
} else {
    echo "<script>alert('ID tidak ditemukan'); window.location.href='hutang.php';</script>";
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Hutang</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        /* CSS untuk mempercantik card dan form */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .container {
            max-width: 600px;
            padding: 20px;
        }

        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
            background-color: #ffffff;
        }

        .card-body {
            padding: 20px;
        }

        h2 {
            font-size: 24px;
            color: #00796b;
            text-align: center;
            margin-bottom: 20px;
        }

        .form-group label {
            font-weight: bold;
            font-size: 14px;
            color: #333;
        }

        .form-control {
            border-radius: 5px;
            padding: 10px;
            border: 1px solid #ddd;
            transition: all 0.3s ease-in-out;
        }

        .form-control:focus {
            border-color: #00796b;
            box-shadow: 0px 0px 5px rgba(0, 121, 107, 0.5);
        }

        .btn-secondary {
            background-color: rgb(7, 7, 7);
            border-color: rgb(7, 7, 7);
            color: white;
            width: 40%;
            margin-top: 15px;

        }

        .btn-warning:hover {
            background-color: rgb(70, 73, 71);
            border-color: rgb(82, 85, 83);
        }
    </style>
</head>

<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card shadow-sm">
                    <div class="card-body">
                        <h3 class="text-center mb-4">Edit Hutang</h3>
                        <form method="post">
                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label>Nama Hutang</label>
                                    <input type="text" class="form-control" name="nama_hutang" value="<?= htmlspecialchars($data['nama_hutang'] ?? '') ?>" required>
                                </div>
                                <div class="form-group col-md-6">
                                    <label>Jumlah Hutang</label>
                                    <input type="number" class="form-control" name="jumlah_hutang" value="<?= htmlspecialchars($data['jumlah_hutang'] ?? '') ?>" required>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label>Tanggal Jatuh Tempo</label>
                                    <input type="date" class="form-control" name="tanggal_jatuh_tempo" value="<?= htmlspecialchars($data['tanggal_jatuh_tempo'] ?? '') ?>" required>
                                </div>
                                <div class="form-group col-md-6">
                                    <label>Nama Pemberi Hutang</label>
                                    <input type="text" class="form-control" name="nama_pemberi_hutang" value="<?= htmlspecialchars($data['nama_pemberi_hutang'] ?? '') ?>" required>
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Status Pembayaran</label>
                                <select class="form-control" name="status_pembayaran">
                                    <option value="Belum Dibayar" <?= ($data['status_pembayaran'] ?? '') == 'Belum Dibayar' ? 'selected' : '' ?>>Belum Dibayar</option>
                                    <option value="Sudah Dibayar" <?= ($data['status_pembayaran'] ?? '') == 'Sudah Dibayar' ? 'selected' : '' ?>>Sudah Dibayar</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Keterangan Hutang</label>
                                <textarea class="form-control" name="keterangan_hutang" rows="3" required><?= htmlspecialchars($data['keterangan_hutang'] ?? '') ?></textarea>
                            </div>
                            <button type="submit" class="btn btn-secondary btn-block">
                                <i class="fas fa-edit"></i> Update
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>