<?php
include 'Koneksi/db_connection.php';

$email = isset($_POST['email']) ? $_POST['email'] : '';

function processForgotPassword($conn, $email)
{
    $sql = "SELECT id, username FROM users WHERE email = ?";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        die("Prepare statement failed: " . $conn->error);
    }

    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Email valid, proses reset password
        echo "<script>
            alert('Email ditemukan. Silakan masukkan password baru.');
            window.location.href = 'reset_password.php?email=" . urlencode($email) . "';
        </script>";
    } else {
        echo "<script>
            alert('Email tidak ditemukan.');
            window.location.href = 'forgot_password.html';
        </script>";
    }

    $stmt->close();
}

processForgotPassword($conn, $email);
$conn->close();
