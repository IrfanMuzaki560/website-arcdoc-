<?php
session_start();
include('Koneksi/db_connection.php'); // Pastikan file ini berisi koneksi yang benar

// Cek apakah ID ada dalam URL
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Hapus data dari database
    $sql = "DELETE FROM hutang WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        echo "<script>alert('Hutang berhasil dihapus'); window.location.href='hutang.php';</script>";
    } else {
        echo "<script>alert('Error: " . $stmt->error . "');</script>";
    }
} else {
    echo "<script>alert('ID tidak ditemukan'); window.location.href='hutang.php';</script>";
}
