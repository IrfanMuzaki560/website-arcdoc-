<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.html");
    exit();
}

// Database connection
include('Koneksi/db_connection.php');

// Get total number of documents
$query_total = "SELECT COUNT(*) as total_docs FROM documents WHERE user_id = {$_SESSION['user_id']}";
$result_total = $conn->query($query_total);
$total_docs = $result_total->fetch_assoc()['total_docs'];

// Get total size of all documents
$query_size = "SELECT SUM(file_size) as total_size FROM documents WHERE user_id = {$_SESSION['user_id']}";
$result_size = $conn->query($query_size);
$total_size = $result_size->fetch_assoc()['total_size'];

// Get number of documents uploaded in the last 24 hours
$query_recent = "SELECT COUNT(*) as recent_docs FROM documents WHERE user_id = {$_SESSION['user_id']} AND created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)";
$result_recent = $conn->query($query_recent);
$recent_docs = $result_recent->fetch_assoc()['recent_docs'];

// Get most common file types
$query_type = "SELECT file_type, COUNT(*) as type_count FROM documents WHERE user_id = {$_SESSION['user_id']} GROUP BY file_type ORDER BY type_count DESC LIMIT 5";
$result_type = $conn->query($query_type);
$file_types = [];
$type_counts = [];
while ($row = $result_type->fetch_assoc()) {
    $file_types[] = $row['file_type'];
    $type_counts[] = $row['type_count'];
}

// Get uploads per day for the last 7 days
$query_daily = "SELECT DATE(created_at) as date, COUNT(*) as count FROM documents WHERE user_id = {$_SESSION['user_id']} AND created_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY) GROUP BY DATE(created_at) ORDER BY date";
$result_daily = $conn->query($query_daily);
$dates = [];
$daily_counts = [];
while ($row = $result_daily->fetch_assoc()) {
    $dates[] = $row['date'];
    $daily_counts[] = $row['count'];
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document Analytics</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            display: flex;
            height: 100vh;
            overflow: hidden;
            margin: 0;
            font-family: Arial, sans-serif;
        }

        .content {
            margin-left: 0px;
            margin-top: 0px;
            padding: 15px;
            flex-grow: 1;
            overflow-y: auto;
            background-color: #e9ecef;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.3);
            width: calc(100% - 190px);
            max-width: 100%;
            box-sizing: border-box;
        }

        .container {
            padding-top: 2rem;
        }

        .content-wrapper {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .card {
            font-size: 0.9rem;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s, box-shadow 0.3s;
            border: 1px solid #dee2e6;
        }

        .card-body {
            padding: 1rem;
        }

        .card-title {
            font-size: 1.1rem;
            font-weight: bold;
            color: rgb(8, 8, 8);
        }

        .card-text {
            font-size: 0.9rem;
            color: rgb(32, 36, 35);
        }

        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2);
        }

        canvas {
            max-height: 300px;
            max-width: 100%;
            border-radius: 8px;
            background-color: #ffffff;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            /* Add spacing between chart and content */
        }

        /* Button Styles */
        .btn-primary {
            background: linear-gradient(45deg, #004d40, #00251a);
            border: none;
        }

        .btn-primary:hover {
            background: linear-gradient(45deg, #00251a, #004d40);
        }

        /* Responsive Design for Smaller Screens */
        @media (max-width: 768px) {
            .content {
                margin-left: 0;
                margin-top: 10px;
                max-width: 100%;
            }

            .form-inline {
                flex-direction: column;
                align-items: stretch;
            }
        }
    </style>
</head>

<body>

    <!-- Content -->
    <div class="content">
        <div class="container">
            <!-- Content Wrapper with Unified Background -->
            <div class="content-wrapper">
                <!-- Row for Horizontal Layout -->
                <div class="row">
                    <!-- Document Count Card -->
                    <div class="col-md-4 mb-4">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">Total Documents</h5>
                                <p class="card-text"><?php echo $total_docs; ?></p>
                            </div>
                        </div>
                    </div>

                    <!-- Total Size Card -->
                    <div class="col-md-4 mb-4">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">Total Size</h5>
                                <p class="card-text"><?php echo number_format($total_size / 1024 / 1024, 2); ?> MB</p>
                            </div>
                        </div>
                    </div>

                    <!-- Recent Uploads Card -->
                    <div class="col-md-4 mb-4">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">Recent Uploads (Last 24 Hours)</h5>
                                <p class="card-text"><?php echo $recent_docs; ?></p>
                            </div>
                        </div>
                    </div>
                </div> <!-- End Row -->

                <!-- Back Button -->
                <div class="mb-4">
                    <a href="index.php" class="btn btn-secondary">
                        <i class="fas fa-arrow-left"></i> Kembali
                    </a>
                </div>

                <!-- Script for Charts -->
                <script>
                    // File Types Chart
                    var ctx1 = document.getElementById('fileTypeChart').getContext('2d');
                    new Chart(ctx1, {
                        type: 'pie',
                        data: {
                            labels: <?php echo json_encode($file_types); ?>,
                            datasets: [{
                                data: <?php echo json_encode($type_counts); ?>,
                                backgroundColor: ['#ff6384', '#36a2eb', '#cc65fe', '#ffce56', '#ff5733']
                            }]
                        }
                    });
                </script>
            </div>
        </div>
    </div>

</body>

</html>