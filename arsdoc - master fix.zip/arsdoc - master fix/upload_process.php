<?php
session_start();
include('Koneksi/db_connection.php');

// Define allowed file extensions
$allowedExtensions = ['jpg', 'jpeg', 'png', 'pdf', 'txt', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'csv'];
$allowedMimeTypes = [
    'image/jpeg',
    'image/png',
    'application/pdf',
    'text/plain',
    'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/vnd.ms-excel',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'application/vnd.ms-powerpoint',
    'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    'text/csv'
];
$maxFileSize = 1 * 1024 * 1024 * 1024; // 1 GB
$maxFiles = 50; // Maximum number of files allowed

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = htmlspecialchars($_POST['documentTitle'] ?? '');
    $description = htmlspecialchars($_POST['documentDescription'] ?? '');
    $password = $_POST['documentPassword'] ?? '';
    $uploadType = $_POST['uploadType'] ?? '';
    $files = $_FILES['documentFile'] ?? [];

    if (!isset($_SESSION['username'])) {
        $_SESSION['message'] = 'User tidak login.';
        header("Location: index.php");
        exit();
    }

    $username = $_SESSION['username'];
    $userQuery = "SELECT id FROM users WHERE username = ?";
    $userStmt = $conn->prepare($userQuery);
    $userStmt->bind_param("s", $username);
    $userStmt->execute();
    $userResult = $userStmt->get_result();

    if ($userResult->num_rows > 0) {
        $userId = $userResult->fetch_assoc()['id'];
    } else {
        $_SESSION['message'] = 'User tidak ditemukan.';
        header("Location: index.php");
        exit();
    }

    $uploadDir = 'F:/uploads';
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }

    $userFolder = $uploadDir . '/' . $username;
    if (!is_dir($userFolder)) {
        mkdir($userFolder, 0755, true);
    }

    $documentFolder = $userFolder . '/' . $title;
    if (!is_dir($documentFolder)) {
        mkdir($documentFolder, 0755, true);
    }

    $hashedPassword = $password ? password_hash($password, PASSWORD_DEFAULT) : null;

    $successCount = 0;
    $failedFiles = [];
    $totalFiles = count($files['name'] ?? []);

    if ($totalFiles > $maxFiles) {
        $_SESSION['message'] = "Anda hanya bisa mengupload maksimal $maxFiles file dalam satu waktu.";
        header("Location: index.php");
        exit();
    }

    if (isset($files['error']) && is_array($files['error'])) {
        foreach ($files['error'] as $key => $error) {
            if ($error == UPLOAD_ERR_OK) {
                $tmpName = $files['tmp_name'][$key];
                $fileName = basename($files['name'][$key]);
                $filePath = $documentFolder . '/' . $fileName;
                $fileType = mime_content_type($tmpName);
                $fileExtension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
                $fileSize = filesize($tmpName);
                $fileContent = file_get_contents($tmpName);

                if ($fileSize > $maxFileSize) {
                    $failedFiles[] = "$fileName - Ukuran file melebihi batas maksimum 1 GB.";
                    continue;
                }

                if (in_array($fileExtension, $allowedExtensions) && in_array($fileType, $allowedMimeTypes)) {
                    if (move_uploaded_file($tmpName, $filePath)) {
                        $query = "INSERT INTO documents (user_id, title, description, file_name, file_type, file_size, file_content, file_path, created_at, password) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?)";
                        $stmt = $conn->prepare($query);
                        $stmt->bind_param("isssissss", $userId, $title, $description, $fileName, $fileType, $fileSize, $fileContent, $filePath, $hashedPassword);

                        if ($stmt->execute()) {
                            $successCount++;
                        } else {
                            $failedFiles[] = "$fileName - Gagal menyimpan ke database.";
                        }
                    } else {
                        $failedFiles[] = "$fileName - Gagal memindahkan file.";
                    }
                } else {
                    $failedFiles[] = "$fileName - Ekstensi atau tipe file tidak diperbolehkan.";
                }
            } else {
                $failedFiles[] = $files['name'][$key] . " - Kesalahan saat upload: $error";
            }
        }
    }

    if ($successCount > 0) {
        $_SESSION['message'] = "Berhasil mengupload $successCount file.";
    }
    if (!empty($failedFiles)) {
        $_SESSION['message'] .= " Gagal mengupload " . count($failedFiles) . " file: " . implode(', ', $failedFiles);
    }

    header("Location: index.php");
    exit();
}
