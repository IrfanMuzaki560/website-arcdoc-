<?php
session_start();
include('Koneksi/db_connection.php');

// Pastikan pengguna sudah login
if (!isset($_SESSION['username'])) {
    $_SESSION['message'] = 'Anda harus login terlebih dahulu.';
    header("Location: login.html");
    exit();
}

$username = $_SESSION['username'];

// Ambil user_id dari database berdasarkan username
$userQuery = "SELECT id FROM users WHERE username = ?";
$userStmt = $conn->prepare($userQuery);
$userStmt->bind_param("s", $username);
$userStmt->execute();
$userResult = $userStmt->get_result();

if ($userResult->num_rows > 0) {
    $userRow = $userResult->fetch_assoc();
    $userId = $userRow['id'];
} else {
    $_SESSION['message'] = 'Pengguna tidak ditemukan.';
    header("Location: login.php");
    exit();
}

// Variabel untuk menyimpan query pencarian
$searchTitle = '';
$searchCategory = '';
$searchType = 'title'; // Default ke pencarian berdasarkan judul
$whereClause = "user_id = ?"; // Filter hanya dokumen milik user yang login
$params = [$userId];
$types = 'i';

// Cek apakah ada parameter pencarian
if (isset($_GET['searchTitle'])) {
    $searchTitle = '%' . htmlspecialchars($_GET['searchTitle'], ENT_QUOTES, 'UTF-8') . '%';
    $searchType = isset($_GET['searchType']) ? htmlspecialchars($_GET['searchType'], ENT_QUOTES, 'UTF-8') : 'title';

    // Tentukan kolom pencarian berdasarkan jenis pencarian
    switch ($searchType) {
        case 'description':
            $whereClause .= " AND description LIKE ?";
            break;
        case 'filename':
            $whereClause .= " AND file_name LIKE ?";
            break;
        case 'title':
        default:
            $whereClause .= " AND title LIKE ?";
            break;
    }

    $params[] = $searchTitle;
    $types .= 's'; // Karena parameter pencarian berupa string
}

if (isset($_GET['searchCategory']) && $_GET['searchCategory'] !== '') {
    $searchCategory = htmlspecialchars($_GET['searchCategory'], ENT_QUOTES, 'UTF-8');
    $whereClause .= " AND category = ?";
    $params[] = $searchCategory;
    $types .= 's'; // Kategori dianggap string
}

// Penanganan pengunduhan dokumen
if (isset($_GET['id']) && isset($_GET['action']) && $_GET['action'] === 'download') {
    $id = intval($_GET['id']);

    $query = "SELECT file_name, file_type, file_content FROM documents WHERE id = ? AND user_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ii", $id, $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    $document = $result->fetch_assoc();

    if ($document) {
        $fileName = $document['file_name'];
        $fileType = $document['file_type'];
        $fileContent = $document['file_content'];

        header('Content-Description: File Transfer');
        header('Content-Type: ' . $fileType);
        header('Content-Disposition: attachment; filename="' . basename($fileName) . '"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . strlen($fileContent));
        echo $fileContent;
        exit();
    } else {
        echo 'Dokumen tidak ditemukan.';
    }

    $stmt->close();
    $conn->close();
    exit();
}
//Penanganan penghapusan dokumen
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id']) && isset($_POST['action']) && $_POST['action'] === 'delete') {
    $id = intval($_POST['id']);
    $username = $_SESSION['username'];

    // Ambil file_path dari database berdasarkan ID dokumen
    $query = "SELECT file_path FROM documents WHERE id = ? AND user_id = (SELECT id FROM users WHERE username = ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("is", $id, $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Ambil path file dari hasil query
        $document = $result->fetch_assoc();
        $filePath = $document['file_path'];

        // Cek apakah file fisik ada dan hapus file jika ada
        if (file_exists($filePath)) {
            if (unlink($filePath)) { // Menghapus file fisik
                // Hapus entri dokumen dari database
                $deleteQuery = "DELETE FROM documents WHERE id = ? AND user_id = (SELECT id FROM users WHERE username = ?)";
                $deleteStmt = $conn->prepare($deleteQuery);
                $deleteStmt->bind_param("is", $id, $username);

                if ($deleteStmt->execute()) {
                    echo json_encode(['success' => true, 'message' => 'Dokumen berhasil dihapus.']);
                } else {
                    echo json_encode(['success' => false, 'message' => 'Gagal menghapus dokumen dari database.']);
                }
            } else {
                echo json_encode(['success' => false, 'message' => 'Gagal menghapus file fisik.']);
            }
        } else {
            echo json_encode(['success' => false, 'message' => 'File tidak ditemukan di server.']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Dokumen tidak ditemukan.']);
    }
    exit();
}

// Penanganan pengeditan dokumen
if (isset($_POST['action'])) {
    $action = $_POST['action'];
    $id = intval($_POST['id']);

    if ($action === 'edit') {
        $query = "SELECT * FROM documents WHERE id = ? AND user_id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ii", $id, $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        $document = $result->fetch_assoc();

        if ($document) {
            echo '<form id="editForm" action="index.php" method="post">';
            echo '<input type="hidden" name="action" value="update">';
            echo '<input type="hidden" name="id" value="' . htmlspecialchars($document['id'], ENT_QUOTES, 'UTF-8') . '">';
            echo '<div class="form-group">';
            echo '<label for="editTitle">Judul Dokumen</label>';
            echo '<input type="text" class="form-control" id="editTitle" name="editTitle" value="' . htmlspecialchars($document['title'], ENT_QUOTES, 'UTF-8') . '" required />';
            echo '</div>';
            echo '<div class="form-group">';
            echo '<label for="editDescription">Deskripsi Dokumen</label>';
            echo '<textarea class="form-control" id="editDescription" name="editDescription" rows="3" required>' . htmlspecialchars($document['description'], ENT_QUOTES, 'UTF-8') . '</textarea>';
            echo '</div>';
            echo '<button type="submit" class="btn btn-secondary">Simpan Perubahan</button>';
            echo '</form>';
        } else {
            echo 'Dokumen tidak ditemukan.';
        }
        $stmt->close();
    } elseif ($action === 'update') {
        $title = $_POST['editTitle'];
        $description = $_POST['editDescription'];

        $query = "UPDATE documents SET title = ?, description = ? WHERE id = ? AND user_id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ssii", $title, $description, $id, $userId);
        if ($stmt->execute()) {
            $_SESSION['message'] = 'Dokumen berhasil diperbarui.';
        } else {
            $_SESSION['message'] = 'Gagal memperbarui dokumen.';
        }
        $stmt->close();
        header("Location: index.php");
        exit();
    }
}

// Pagination
$docs_per_page = 20;
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$offset = ($page - 1) * $docs_per_page;

// Hitung total dokumen
$query_count = "SELECT COUNT(*) as total_docs FROM documents WHERE $whereClause";
$stmt_count = $conn->prepare($query_count);
$stmt_count->bind_param($types, ...$params);
$stmt_count->execute();
$result_count = $stmt_count->get_result();
$total_docs = $result_count->fetch_assoc()['total_docs'];
$stmt_count->close();

// Ambil dokumen dengan pagination
$query = "SELECT * FROM documents WHERE $whereClause ORDER BY created_at DESC LIMIT ? OFFSET ?";
$params[] = $docs_per_page;
$params[] = $offset;
$types .= 'ii';

$stmt = $conn->prepare($query);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$result = $stmt->get_result();
$documents = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $documents[] = $row;
    }
}
$stmt->close();
$conn->close();


// Pagination link
$total_pages = ceil($total_docs / $docs_per_page);
if ($total_pages > 1) {
    for ($i = 1; $i <= $total_pages; $i++) {
        echo "<a href='?page=$i'>" . $i . "</a> ";
    }
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Arsip Documents</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSkt5U6xwE5z74U1E6H+uwjEkVTNx0BxA8GBF2vI1p" crossorigin="anonymous">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" />
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* Gaya Umum */
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: rgba(255, 255, 255, 0);
            padding-top: 100px;
            /* Total tinggi header + navbar */
        }

        .header-top {
            background-color: rgba(13, 17, 24, 0.16);
            /* Warna latar belakang */
            color: #ffffff;
            padding: 10px 20px;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            z-index: 1000;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .navbar {
            background-color: rgb(255, 255, 255);
            /* Sama dengan header-top */
            color: #ffffff;
            padding: 10px 20px;
            position: fixed;
            top: 50px;
            /* Tepat di bawah header-top */
            left: 0;
            width: 100%;
            z-index: 999;
            /* Sedikit lebih rendah dari header */
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .content {
            padding: 10px;
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin: 20px auto;
            font-size: 16px;
            max-width: 1500px;
            /* Lebar maksimum konten */

        }

        /* Container */
        .container {
            padding-top: 1rem;
        }

        /* Tabel */
        .table-wrapper {
            max-height: 400px;
            overflow-y: auto;
            margin-top: 20px;
        }

        .table {
            font-size: 14px;
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .table thead th {
            padding: 8px;
            background-color: rgba(1, 13, 24, 0.81);
            color: #ffffff;
            font-size: 14px;
        }

        .table tbody td {
            padding: 8px;
        }

        .table tbody tr:nth-child(even) {
            background-color: #f1f1f1;
        }

        .table tbody tr:hover {
            background-color: #b2dfdb;
        }

        /* Form */
        #ratingForm .form-control {
            font-size: 14px;
            padding: 8px;
        }

        #ratingForm .btn {
            font-size: 14px;
            padding: 8px 15px;
            border: 1px solid #80cbc4;
            background-color: #80cbc4;
            color: white;
        }

        #ratingForm .btn:hover {
            background-color: #004d40;
            border-color: #004d40;
        }

        /* Responsif untuk tampilan layar kecil */
        @media (max-width: 768px) {

            /* Header */
            .header-top {
                padding: 10px;
                text-align: center;
                background-color: #f8f9fa;
                border-bottom: 1px solid #ddd;
                flex-wrap: wrap;

            }

            .header-top .user-icon,
            .header-top .current-date,
            .header-top .user-profile {
                margin-bottom: 5px;
                text-align: center;
            }

            .header-top .user-icon span,
            .header-top .current-date span,
            .header-top .user-profile span {
                font-size: 12px;
            }

            /* Navbar */
            .navbar {
                padding: 10px;
                margin-top: 10px;
                /* Mengurangi jarak atas navbar dengan header */
                /* Pastikan navbar tidak tumpang tindih dengan header */
                background-color: #ffffff;
                border-bottom: 1px solid #ddd;
                position: relative;
                /* Menjaga posisi navbar */
            }

            .navbar-collapse {
                display: block;
                width: 100%;
                text-align: center;
                overflow-x: auto;
                white-space: nowrap;
            }

            .navbar-nav {
                display: flex;
                flex-direction: column;
                padding: 0;
                align-items: center;
            }

            .navbar-nav li {
                width: 100%;
                text-align: center;
            }

            .navbar-nav li a {
                font-size: 14px;
                color: #FF5733;
                display: block;
                padding: 8px 5px;
                border-radius: 5px;
            }

            .navbar-toggler {
                margin-left: auto;
                border: none;
                padding: 5px 10px;
            }

            /* Dropdown */
            .dropdown-menu {
                position: relative;
                width: 100%;
                text-align: center;
                background-color: #ffffff;
                border: 1px solid #ddd;
            }

            /* Form Pencarian */
            .form-inline {
                flex-direction: column;
                align-items: center;
                width: 100%;
                margin-bottom: 10px;
            }

            .form-inline .input-group {
                width: 100%;
            }

            .form-inline .form-control {
                font-size: 14px;
            }

            /* Konten */
            .content {
                margin-top: 50px;
                padding: 10px;
            }

            /* Tabel */
            .table-wrapper {
                overflow-x: auto;
                /* Tambahkan scroll jika tabel terlalu besar */
            }

            .table {
                width: 100%;
                font-size: 12px;
            }

            .table thead th {
                font-size: 12px;
                white-space: nowrap;
                /* Hindari memotong teks di header */
            }

            /* Tombol Aksi */
            .btn {
                font-size: 12px;
                padding: 5px 10px;
                margin: 2px;
            }

            /* Modal */
            .modal-dialog {
                width: 90%;
                margin: auto;
            }

            .modal-header {
                padding: 10px;
            }

            .modal-body {
                font-size: 14px;
            }

            /* Footer */
            footer {
                font-size: 10px;
                padding: 10px 5px;
            }

            .navbar-nav .nav-item {
                margin: 5px 0;
                /* Beri jarak vertikal antar menu */
            }

            .navbar-toggler {
                border: none;
                color: #fff;
                padding: 8px 12px;
            }

            .navbar-toggler-icon {
                background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 30 30'%3E%3Cpath stroke='rgba%28255, 87, 51, 1%29' stroke-width='2' d='M4 7h22M4 15h22M4 23h22'/%3E%3C/svg%3E");
            }

            /* Membuat form pencarian menjadi vertikal */
            .form-inline {
                flex-direction: column;
                align-items: stretch;
                width: 100%;
            }

            /* Mengatur ukuran tombol pencarian pada layar kecil */
            .form-inline .btn {
                width: 50%;
                /* Tombol menyesuaikan lebar tanpa background */
                background-color: transparent;
                /* Menghapus background */
                color: rgb(167, 173, 179);
                /* Mengatur warna teks */
                padding: 10px;
                border: none;
                /* Menghilangkan border */
            }

            .form-inline .btn:hover {
                background-color: transparent;
                /* Menghapus background saat hover */
                color: rgb(190, 203, 216);
                /* Mengubah warna teks saat hover */
            }

            /* Mengatur dropdown dan input agar memenuhi lebar layar */
            .form-inline .form-control,
            .form-inline .input-group {
                width: 100%;
                margin-bottom: 10px;
                /* Menambahkan jarak antara elemen */
            }


            /* Mengatur dropdown agar lebih kecil */
            .form-inline select {
                font-size: 14px;
                padding: 8px;
            }

            /* Mengatur jarak antar elemen */
            .form-inline .input-group-append {
                width: 100%;
            }

            .form-inline .input-group-append button {
                width: 100%;
                /* Tombol pencarian juga memenuhi lebar layar */
                padding: 7px;
            }

        }
    </style>
</head>

<body>
    <header class="header-top py-2 bg-dark text-white">
        <div class="container d-flex justify-content-between align-items-center">
            <!-- Tombol Hamburger Menu -->
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <!-- Tanggal & Waktu -->
            <div class="current-date d-flex align-items-center"
                style="color: #FF5733; font-weight: bold; cursor: pointer;"
                onclick="showDateTimeDetails()">
                <i class="bi bi-calendar-event mr-2"></i>
                <span id="date"></span>
                <span class="mx-2">|</span>
                <i class="bi bi-clock mr-2"></i>
                <span id="clock"></span>
            </div>


            <!-- Username & Icon -->
            <div class="user-profile d-flex align-items-center" style="color: #00d2ff;">
                <a href="profile.php" class="d-flex align-items-center" style="text-decoration: none; color: inherit;">
                    <i class="bi bi-person mr-2" style="color: #FF5733;"></i> <!-- Ikon pengguna -->
                    <span id="username" style="font-weight: bold; color:rgb(255, 255, 255);">
                        <?php echo htmlspecialchars($username); ?>
                    </span>
                    <!-- Kata tambahan -->
                    <span style="font-style: italic; color: #FF5733; margin-left: 5px;">(Oyyyy!)</span>
                </a>
            </div>


    </header>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark fixed-top">
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <!-- Form Pencarian -->
        <form method="get" action="index.php" class="form-inline my-2 my-lg-0 ml-auto">
            <!-- Dropdown untuk memilih jenis pencarian -->
            <select class="form-control mr-2" id="searchType" name="searchType">
                <option value="title" <?= (!isset($_GET['searchType']) || $_GET['searchType'] === 'title') ? 'selected' : '' ?>>Judul</option>
                <option value="description" <?= isset($_GET['searchType']) && $_GET['searchType'] === 'description' ? 'selected' : '' ?>>Deskripsi</option>
                <option value="filename" <?= isset($_GET['searchType']) && $_GET['searchType'] === 'filename' ? 'selected' : '' ?>>Nama File</option>
            </select>

            <div class="input-group input-group-rounded">
                <!-- Input untuk memasukkan kata kunci pencarian -->
                <input class="form-control" type="text" id="searchTitle" name="searchTitle" placeholder="Cari..." value="<?= isset($_GET['searchTitle']) ? htmlspecialchars($_GET['searchTitle']) : '' ?>" />

                <!-- Tombol Cari -->
                <div class="input-group-append">
                    <button class="btn btn-primary" type="submit">
                        <i class="fa fa-search"></i>
                    </button>
                </div>
            </div>
        </form>

        <!-- Navbar Menu -->
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <!-- Dropdown Reports -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownReports" role="button" data-bs-toggle="dropdown" aria-expanded="false" style="color: #FF5733;">
                        <i class="fas fa-file-alt"></i> Menu
                    </a>

                    <ul class="dropdown-menu" aria-labelledby="navbarDropdownReports">
                        <!--   <li><a class="dropdown-item" href="home.php"><i class="bi bi-house-door"></i> Home</a></li>  -->
                        <li><a class="dropdown-item" href="data.php"><i class="bi bi-box"></i> Barang</a></li>
                        <li><a class="dropdown-item" href="tdl.php"><i class="bi bi-lock"></i> To do list</a></li>
                        <!--<li><a class="dropdown-item" href="hutang.php"><i class="bi bi-bell"></i> Hutang</a></li>
                        <li><a class="dropdown-item" href="olah.php"><i class="bi bi-file-earmark"></i> Olah Data</a></li> -->
                        <li><a class="dropdown-item" href="project.php"><i class="bi bi-folder"></i> Notes</a></li>
                        <li><a class="dropdown-item" href="analytics.php"><i class="bi bi-bar-chart"></i> Analitics</a></li>
                    </ul>

                </li>

                <!-- Dropdown Settings -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownSettings" role="button" data-bs-toggle="dropdown" aria-expanded="false" style="color: #FF5733;">
                        <i class=" fas fa-cogs"></i> Settings
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdownSettings">
                        <li><a class="dropdown-item" href="profile.php"><i class="bi bi-person-circle"></i> Profile</a></li>
                        <li><a class="dropdown-item" href="users.php"><i class="bi bi-person-lines-fill"></i> Users</a></li>
                        <li><a class="dropdown-item" href="settings.php"><i class="bi bi-gear-fill"></i> Settings</a></li>
                        <li><a class="dropdown-item" href="login.html"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
                    </ul>

                </li>
            </ul>
        </div>
    </nav>
    <div class="content">
        <div class="container-fluid">

            <nav aria-label="Page navigation">
                <ul class="pagination pagination-sm">
                    <!-- Tombol Previous -->
                    <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>">
                        <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page' => max(1, $page - 1)])) ?>" aria-label="Previous">
                            <span aria-hidden="true">&lsaquo;</span>
                        </a>
                    </li>

                    <?php
                    // Menentukan halaman yang akan ditampilkan
                    $start_page = max(1, $page - 1); // Halaman sebelumnya
                    $end_page = min($total_pages, $page + 1); // Halaman berikutnya

                    // Jika lebih dari 3 halaman, kita tampilkan halaman pertama dan terakhir
                    if ($total_pages > 3) {
                        // Halaman pertama
                        echo '<li class="page-item ' . ($start_page == 1 ? 'active' : '') . '"><a class="page-link" href="?' . http_build_query(array_merge($_GET, ['page' => 1])) . '">1</a></li>';

                        // Halaman sebelumnya (jika tidak sudah di halaman pertama)
                        if ($start_page > 1) {
                            echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
                        }
                    }

                    // Menampilkan halaman sekitar halaman aktif (dalam rentang 3 halaman)
                    for ($i = $start_page; $i <= $end_page; $i++) {
                        if ($i <= $total_pages) {
                            echo '<li class="page-item ' . ($i == $page ? 'active' : '') . '"><a class="page-link" href="?' . http_build_query(array_merge($_GET, ['page' => $i])) . '">' . $i . '</a></li>';
                        }
                    }

                    // Jika lebih dari 3 halaman, tampilkan halaman terakhir
                    if ($total_pages > 3) {
                        if ($end_page < $total_pages) {
                            echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
                        }
                        echo '<li class="page-item ' . ($end_page == $total_pages ? 'active' : '') . '"><a class="page-link" href="?' . http_build_query(array_merge($_GET, ['page' => $total_pages])) . '">' . $total_pages . '</a></li>';
                    }
                    ?>

                    <!-- Tombol Next -->
                    <li class="page-item <?= $page >= $total_pages ? 'disabled' : '' ?>">
                        <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page' => min($total_pages, $page + 1)])) ?>" aria-label="Next">
                            <span aria-hidden="true">&rsaquo;</span>
                        </a>
                    </li>
                </ul>
            </nav>

            <!-- Menampilkan informasi halaman aktif dan total halaman -->
            <p class="mt-3">Halaman <?= $page ?> dari <?= $total_pages ?></p>
            <h2 class="mt-3" style="font-family: Arial, sans-serif; font-size: 24px; font-weight: bold; color: #333;">
                Unggah Dokumen
            </h2>
            <!--ini ke bawah yang di ubah -->
            <form id="documentForm" action="upload_process.php" method="post" enctype="multipart/form-data">
                <!-- Form Fields -->
                <div class="form-group">
                    <label for="documentTitle">Judul</label>
                    <input type="text" class="form-control" id="documentTitle" name="documentTitle" placeholder="Masukkan judul dokumen" required />
                </div>
                <div class="form-group">
                    <label for="uploadType">Pilih Jenis Unggah</label>
                    <select class="form-control" id="uploadType" name="uploadType" required>
                        <option value="" disabled selected>Pilih opsi</option>
                        <option value="file">Unggah File</option>
                        <!--<option value="folder">Unggah Folder</option>-->
                    </select>
                </div>
                <div class="form-group" id="fileUploadGroup">
                    <label for="documentFile">Unggah Dokumen</label>
                    <input type="file" class="form-control-file" id="documentFile" name="documentFile[]" multiple accept=".pdf,.doc,.docx,.xls,.xlsx,.jpg,.jpeg,.png" />
                </div>
                <div class="form-group" id="folderUploadGroup" style="display: none;">
                    <label for="documentFolder">Unggah Folder</label>
                    <input type="file" class="form-control-file" id="documentFolder" name="documentFolder[]" webkitdirectory directory multiple />
                </div>

                <div class="form-group">
                    <label for="documentDescription">Deskripsi Dokumen</label>
                    <textarea class="form-control" id="documentDescription" name="documentDescription" rows="3" placeholder="Masukkan deskripsi dokumen"></textarea>
                </div>
                <div class="form-group">
                    <label for="documentPassword">Password Dokumen (Opsional)</label>
                    <input type="password" class="form-control" id="documentPassword" name="documentPassword" placeholder="Masukkan password untuk dokumen ini (opsional)" />
                </div>
                <button type="submit" class="btn btn-secondary">
                    <i class="fas fa-upload"></i> Unggah
                </button>



                <!--sampai ini itu pengaturan agar bisa upload all type document-->
                <h2 class="mt-5" style="font-family: Arial, sans-serif; font-size: 24px; font-weight: bold; color: #333;">
                    Daftar Dokumen
                </h2>

                <div class="table-wrapper">
                    <table class="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Judul</th>
                                <th>Deskripsi</th>
                                <th>Nama File</th>
                                <th>Tanggal</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($documents as $document): ?>
                                <tr>
                                    <td><?= $document['id'] ?></td>
                                    <td><?= htmlspecialchars($document['title']) ?></td>
                                    <td><?= htmlspecialchars($document['description']) ?></td>
                                    <td><?= htmlspecialchars($document['file_name']) ?></td>
                                    <td><?= htmlspecialchars($document['created_at']) ?></td>
                                    <td>
                                        <button type="button" class="btn btn-info btn-sm action-btn" data-action="view" data-id="<?= $document['id'] ?>" aria-label="View">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                        <button type="button" class="btn btn-warning btn-sm action-btn" data-action="edit" data-id="<?= $document['id'] ?>" aria-label="Edit">
                                            <i class="fas fa-edit"></i>
                                        </button>

                                        <button type="button" class="btn btn-danger btn-sm"
                                            onclick="confirmDelete(<?= $document['id'] ?>)">
                                            <i class="fas fa-trash"></i>
                                        </button>

                                        <button type="button" class="btn btn-success btn-sm action-btn" data-action="download" data-id="<?= $document['id'] ?>" aria-label="Download">
                                            <i class="fas fa-download"></i>
                                        </button>

                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
        </div>
    </div>
    <!-- Modal -->
    <div class="modal fade" id="modal" tabindex="-1" role="dialog" aria-labelledby="modalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document"> <!-- Tambahkan modal-lg agar lebih besar -->
            <div class="modal-content shadow-lg">
                <div class="modal-header" style="background-color: rgb(25, 27, 27); color: white;">
                    <h5 class="modal-title" id="modalLabel">
                        <i class="fas fa-file-alt"></i> Detail Dokumen
                    </h5>
                    <button type="button" class="btn-close text-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body" id="modalBody">
                    <!-- Konten Modal akan dimuat di sini -->
                    <div class="text-center">
                        <i class="fas fa-spinner fa-spin"></i> Memuat data...
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-danger" data-bs-dismiss="modal">
                        <i class="fas fa-times"></i> Tutup
                    </button>
                </div>
            </div>
        </div>
    </div>

    <footer class="text-center" style="background-color: rgb(0, 0, 0); color: white; min-height: 25px; line-height: 25px; padding: 5px 0;">
        <p style="margin: 0; color:rgb(255, 255, 255); ">&copy; 2025 Website Arsip Dokumen. Semua hak dilindungi.</p>
    </footer>
</body>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script>
    // Fungsi untuk mengupdate tanggal dan waktu
    function updateDateTime() {
        const dateElement = document.getElementById("date");
        const clockElement = document.getElementById("clock");

        const now = new Date();
        const options = {
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        };
        const date = now.toLocaleDateString("id-ID", options); // Format lokal Indonesia
        const time = now.toLocaleTimeString("id-ID");

        dateElement.textContent = date;
        clockElement.textContent = time;
    }

    // Fungsi untuk menampilkan detail tanggal dan waktu
    function showDateTimeDetails() {
        const now = new Date();
        const fullDate = now.toString(); // Detail lengkap tanggal dan waktu
        alert("Detail Tanggal dan Waktu Saat Ini:\n" + fullDate);
    }

    // Update tanggal dan waktu setiap detik
    setInterval(updateDateTime, 1000);

    // Inisialisasi pertama
    updateDateTime();

    /// Menangani klik pada tombol aksi
    document.querySelectorAll('.action-btn').forEach(button => {
        button.addEventListener('click', function() {
            const action = this.getAttribute('data-action');
            const id = this.getAttribute('data-id');

            if (action === 'edit') {
                // Tampilkan modal untuk mengedit dokumen
                fetch('edit.php?id=' + id)
                    .then(response => response.text())
                    .then(data => {
                        document.getElementById('modalBody').innerHTML = data;
                        $('#modal').modal('show');
                    });
            } else if (action === 'view') {
                // Tampilkan modal untuk melihat dokumen
                fetch('view.php?id=' + id)
                    .then(response => response.text())
                    .then(data => {
                        document.getElementById('modalBody').innerHTML = data;
                        $('#modal').modal('show');
                    });
            } else if (action === 'download') {
                // Mengunduh dokumen
                window.location.href = 'download.php?id=' + id; // Mengunduh file dengan GET
            } else if (action === 'delete') {
                // Konfirmasi sebelum menghapus
                if (confirm('Apakah Anda yakin ingin menghapus dokumen ini?')) {
                    // Panggil fungsi untuk menghapus dokumen
                    deleteDocument(id);
                }
            }
        });
    });

    function confirmDelete(docId) {
        if (confirm('Apakah Anda yakin ingin menghapus dokumen ini?')) {
            // Kirim permintaan POST menggunakan fetch
            fetch('index.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: `id=${docId}&action=delete`
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert(data.message); // Tampilkan pesan sukses
                        // Hapus baris tabel terkait dokumen
                        const row = document.querySelector(`button[onclick="confirmDelete(${docId})"]`).closest('tr');
                        if (row) {
                            row.remove();
                        }
                    } else {
                        alert(data.message); // Tampilkan pesan error
                    }
                })
                .catch(error => {
                    console.error('Terjadi kesalahan:', error);
                    alert('Gagal menghapus dokumen. Silakan coba lagi.');
                });
        }
    }






    function updateDateTime() {
        const now = new Date();

        // Format tanggal (DD/MM/YYYY)
        const date = now.toLocaleDateString('id-ID', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });

        // Format jam (HH:MM:SS)
        const time = now.toLocaleTimeString('id-ID', {
            hour12: false
        });

        document.getElementById('date').textContent = date;
        document.getElementById('clock').textContent = time;
    }

    // Jalankan fungsi setiap detik
    setInterval(updateDateTime, 1000);

    // Panggil sekali saat halaman dimuat
    updateDateTime();
    document.getElementById('settingsMenu').addEventListener('click', function(event) {
        event.preventDefault(); // Mencegah link default berfungsi
        var dropdown = document.getElementById('settingsDropdown');
        // Toggle tampilkan/selipkan dropdown
        dropdown.style.display = dropdown.style.display === 'none' || dropdown.style.display === '' ? 'block' : 'none';
    });

    // Menutup dropdown jika klik di luar dropdown
    document.addEventListener('click', function(event) {
        var dropdown = document.getElementById('settingsDropdown');
        var button = document.getElementById('settingsMenu');
        if (!dropdown.contains(event.target) && !button.contains(event.target)) {
            dropdown.style.display = 'none';
        }
    });

    // Menangani perubahan jenis unggahan
    document.getElementById('uploadType').addEventListener('change', function() {
        var uploadType = this.value;
        if (uploadType === 'folder') {
            document.getElementById('fileUploadGroup').style.display = 'none';
            document.getElementById('folderUploadGroup').style.display = 'block';
        } else {
            document.getElementById('fileUploadGroup').style.display = 'block';
            document.getElementById('folderUploadGroup').style.display = 'none';
        }
    });
    document.getElementById('documentForm').addEventListener('submit', function(e) {
        e.preventDefault(); // Menghindari pengiriman formulir default

        var formData = new FormData(this);
        var xhr = new XMLHttpRequest();

        xhr.open('POST', 'upload_process.php', true);

        xhr.upload.addEventListener('progress', function(e) {
            if (e.lengthComputable) {
                var percentComplete = Math.round((e.loaded / e.total) * 100);
                var progressBar = document.getElementById('uploadProgress');
                progressBar.style.width = percentComplete + '%';
                progressBar.innerText = percentComplete + '%';
            }
        });

        xhr.addEventListener('load', function() {
            if (xhr.status === 200) {
                // Menangani kesuksesan
                alert('Upload selesai!');
                // Refresh halaman 
                setTimeout(function() {
                    window.location.reload();
                }, 100);
            } else {
                // Menangani kesalahan
                alert('Terjadi kesalahan saat mengupload file.');
            }
        });

        xhr.addEventListener('error', function() {
            alert('Terjadi kesalahan saat mengupload file.');
        });

        xhr.send(formData);
    });
</script>

</body>

</html>