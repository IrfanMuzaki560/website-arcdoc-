<?php
$servername = "localhost";
$username = "root"; // Ganti dengan nama pengguna database Anda
$password = "1"; // Ganti dengan kata sandi database Anda jika ada
$database = "arsdoc"; // Ganti dengan nama database Anda

// Buat koneksi
$conn = new mysqli($servername, $username, $password, $database);

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}
?>
