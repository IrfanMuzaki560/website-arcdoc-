<?php
session_start();
include('Koneksi/db_connection.php'); // Pastikan file ini berisi koneksi yang benar

// Cek apakah ID ada dalam URL
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Ambil data berdasarkan ID
    $sql = "SELECT * FROM tdl WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $data = $result->fetch_assoc();

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Ambil data dari form
        $nama = $_POST['nama'];
        $hari = $_POST['hari'];
        $tanggal = $_POST['tanggal'];
        $tahun = $_POST['tahun'];
        $kegiatan = $_POST['kegiatan'];
        $start_jam = $_POST['start_jam'];
        $selesai_jam = $_POST['selesai_jam'];
        $proses = isset($_POST['proses']) ? $_POST['proses'] : '';

        // Update data di database
        $sql_update = "UPDATE tdl SET nama = ?, hari = ?, tanggal = ?, tahun = ?, kegiatan = ?, start_jam = ?, selesai_jam = ?, proses = ? WHERE id = ?";
        $stmt_update = $conn->prepare($sql_update);
        $stmt_update->bind_param("sssissssi", $nama, $hari, $tanggal, $tahun, $kegiatan, $start_jam, $selesai_jam, $proses, $id);

        if ($stmt_update->execute()) {
            echo "<script>alert('Data berhasil diupdate'); window.location.href='tdl.php';</script>";
        } else {
            echo "<script>alert('Error: " . $stmt_update->error . "');</script>";
        }
    }
} else {
    echo "<script>alert('ID tidak ditemukan'); window.location.href='tdl.php';</script>";
}
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit To-Do List</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        /* CSS untuk mempercantik card dan form */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .container {
            max-width: 600px;
            padding: 20px;
        }

        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
            background-color: #ffffff;
        }

        .card-body {
            padding: 20px;
        }

        h2 {
            font-size: 24px;
            color: #00796b;
            text-align: center;
            margin-bottom: 20px;
        }

        .form-group label {
            font-weight: bold;
            font-size: 14px;
            color: #333;
        }

        .form-control {
            border-radius: 5px;
            padding: 10px;
            border: 1px solid #ddd;
            transition: all 0.3s ease-in-out;
        }

        .form-control:focus {
            border-color: #00796b;
            box-shadow: 0px 0px 5px rgba(0, 121, 107, 0.5);
        }

        .btn-warning {
            background-color: rgb(7, 7, 7);
            border-color: rgb(7, 7, 7);
            color: white;
            width: 20%;
            margin-top: 15px;

        }

        .btn-warning:hover {
            background-color: rgb(70, 73, 71);
            border-color: rgb(82, 85, 83);
        }
    </style>
</head>

<body>
    <div class="container">

        <div class="card">
            <div class="card-body">
                <form method="post">
                    <h3 class="text-center mb-4">Edit To-Do-List</h3>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label>Nama</label>
                            <input type="text" class="form-control" name="nama" value="<?= htmlspecialchars($data['nama']) ?>" required>
                        </div>
                        <div class="form-group col-md-6">
                            <label>Hari</label>
                            <input type="text" class="form-control" name="hari" value="<?= htmlspecialchars($data['hari']) ?>" required>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label>Tanggal</label>
                            <input type="date" class="form-control" name="tanggal" value="<?= htmlspecialchars($data['tanggal']) ?>" required>
                        </div>
                        <div class="form-group col-md-6">
                            <label>Kegiatan</label>
                            <input type="text" class="form-control" name="kegiatan" value="<?= htmlspecialchars($data['kegiatan']) ?>" required>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label>Mulai (Jam)</label>
                            <input type="time" class="form-control" name="start_jam" value="<?= htmlspecialchars($data['start_jam']) ?>" required>
                        </div>
                        <div class="form-group col-md-6">
                            <label>Selesai (Jam)</label>
                            <input type="time" class="form-control" name="selesai_jam" value="<?= htmlspecialchars($data['selesai_jam']) ?>" required>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-12">
                            <label>Proses</label>
                            <select class="form-control" name="proses">
                                <option value="Selesai" <?= $data['proses'] == 'Selesai' ? 'selected' : '' ?>>Selesai</option>
                                <option value="Belum" <?= $data['proses'] == 'Belum' ? 'selected' : '' ?>>Belum</option>
                            </select>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-secondary">
                        <i class="fas fa-edit"></i> Update
                    </button>
                </form>
            </div>
        </div>
    </div>
</body>

</html>