<?php
include('Koneksi/db_connection.php');

// Query untuk mengambil dokumen
$sql = "SELECT * FROM documents";
$result = $conn->query($sql);

$documents = array();

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $documents[] = $row;
    }
}

echo json_encode($documents);

// Tutup koneksi
$conn->close();
